#!/usr/bin/env python3
"""
main.py
=======
FastAPI entry point for ForensicOffice AI.
Local LLM inference + Forensic Compliance Engine.
"""

import os
import subprocess
import httpx
from typing import Optional, List, Dict, Any
from contextlib import asynccontextmanager

from fastapi import FastAPI, WebSocket, HTTPException, BackgroundTasks
from fastapi.staticfiles import StaticFiles
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

# Compliance imports
from compliance.ledger.forensic_ledger import ForensicLedgerManager, LedgerConfig
from compliance.causality.engagement_state_machine import EngagementStateMachine, InputEvent
from compliance.crypto.ed25519_signer import Ed25519Signer, TrustLevel

try:
    from forensic_provenance.v1 import DAWEditEvent, EdgeType, EngagementState
    PROTOBUF_AVAILABLE = True
except ImportError:
    PROTOBUF_AVAILABLE = False

# LLM Server Management
class LLMServer:
    def __init__(self):
        self.process = None
        self.current_model = None
        self.port = 8080

    def start(self, model_path: str, port: int = 8080):
        cmd = [
            "./llama-server",
            "-m", model_path,
            "--port", str(port),
            "-c", "4096",
            "-n", "512",
            "--host", "127.0.0.1"
        ]
        self.process = subprocess.Popen(cmd)
        self.current_model = model_path
        self.port = port

    def stop(self):
        if self.process:
            self.process.terminate()
            self.process = None

class ModelRouter:
    MODELS = {
        "code": "deepseek-coder-1.3b-instruct.Q4_K_M.gguf",
        "general": "granite-3.0-2b-instruct-Q4_K_M.gguf",
        "reasoning": "DeepSeek-R1-Qwen-1.5B.gguf",
        "chat": "Qwen2-1.5B-Instruct-Q4_K_M.gguf",
        "coder": "qwen2.5-coder-3b-instruct-iq4_xs.gguf",
    }

    def route(self, task: str) -> str:
        return self.MODELS.get(task, "granite-3.0-2b-instruct-Q4_K_M.gguf")

# Pydantic models for API
class ChatRequest(BaseModel):
    messages: List[Dict[str, str]]
    task: str = "general"
    stream: bool = False
    asset_id: Optional[str] = None

class ChatResponse(BaseModel):
    response: str
    model_used: str
    tokens_in: int
    tokens_out: int
    compliance_block_id: Optional[str] = None

class LedgerCreateRequest(BaseModel):
    asset_id: str
    asset_type: str = "AUDIO"

class LedgerVerifyResponse(BaseModel):
    valid: bool
    report: Dict[str, Any]

class ComplianceStatus(BaseModel):
    ledger_id: str
    chain_valid: bool
    last_block: int
    hsm_connected: bool
    tsa_status: str
    bgh_conformity: str
    human_mutations: int
    total_duration_sec: int

# Global instances
llm_server = LLMServer()
model_router = ModelRouter()
ledger_manager = ForensicLedgerManager(LedgerConfig())
engagement_sm = EngagementStateMachine()

@asynccontextmanager
async def lifespan(app: FastAPI):
    # Startup
    print("🚀 ForensicOffice AI starting...")
    yield
    # Shutdown
    llm_server.stop()
    print("🛑 ForensicOffice AI stopped")

app = FastAPI(
    title="ForensicOffice AI",
    description="On-Premise Office with Local AI + Forensic Compliance",
    version="1.0.0-forensic",
    lifespan=lifespan
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# =============================================================================
# API ROUTES
# =============================================================================

@app.post("/api/chat", response_model=ChatResponse)
async def chat(request: ChatRequest):
    """Chat with local LLM, with forensic compliance logging."""
    model = model_router.route(request.task)
    model_path = f"./llama.cpp/models/{model}"

    # Ensure server is running with correct model
    if llm_server.current_model != model_path:
        llm_server.stop()
        llm_server.start(model_path)

    # Call llama.cpp server
    async with httpx.AsyncClient() as client:
        response = await client.post(
            f"http://127.0.0.1:{llm_server.port}/v1/chat/completions",
            json={
                "model": model,
                "messages": request.messages,
                "stream": False
            },
            timeout=120.0
        )
        data = response.json()

    # Extract response
    content = data["choices"][0]["message"]["content"]
    usage = data.get("usage", {})

    # Create compliance block if asset_id provided
    compliance_block_id = None
    if request.asset_id and PROTOBUF_AVAILABLE:
        # Create forensic event for this LLM interaction
        event = DAWEditEvent()
        event.event_id = "..."  # Would be generated
        # ... (full event creation)
        # ledger_manager.append_block(ledger_id, event)
        compliance_block_id = event.event_id

    return ChatResponse(
        response=content,
        model_used=model,
        tokens_in=usage.get("prompt_tokens", 0),
        tokens_out=usage.get("completion_tokens", 0),
        compliance_block_id=compliance_block_id
    )

@app.websocket("/api/chat/stream")
async def chat_stream(websocket: WebSocket):
    """Streaming chat via WebSocket."""
    await websocket.accept()
    try:
        while True:
            data = await websocket.receive_json()
            # Streaming implementation
            await websocket.send_text("Streaming not yet implemented")
    except Exception as e:
        await websocket.close()

@app.post("/api/ledger/create")
async def create_ledger(request: LedgerCreateRequest):
    """Create a new forensic ledger for an asset."""
    ledger = ledger_manager.create_ledger(request.asset_id, request.asset_type)
    return {
        "ledger_id": ledger.ledger_id,
        "asset_id": ledger.asset_id,
        "asset_type": request.asset_type,
        "state": "ACTIVE"
    }

@app.get("/api/ledger/{ledger_id}/verify")
async def verify_ledger(ledger_id: str):
    """Verify ledger integrity."""
    valid, report = ledger_manager.verify_integrity(ledger_id)
    return LedgerVerifyResponse(valid=valid, report=report)

@app.get("/api/ledger/{ledger_id}/summary")
async def ledger_summary(ledger_id: str):
    """Get ledger summary."""
    return ledger_manager.get_ledger_summary(ledger_id)

@app.get("/api/compliance/status/{ledger_id}")
async def compliance_status(ledger_id: str):
    """Get real-time compliance status."""
    summary = ledger_manager.get_ledger_summary(ledger_id)
    if "error" in summary:
        raise HTTPException(status_code=404, detail=summary["error"])

    return ComplianceStatus(
        ledger_id=ledger_id,
        chain_valid=summary.get("state") == "ACTIVE",
        last_block=summary.get("blocks", 0),
        hsm_connected=False,  # TODO
        tsa_status="pending",  # TODO
        bgh_conformity=summary.get("bgh", {}).get("estimate", "unknown"),
        human_mutations=summary.get("bgh", {}).get("human_mutations", 0),
        total_duration_sec=summary.get("bgh", {}).get("total_duration_sec", 0)
    )

@app.post("/api/models/switch")
async def switch_model(model: str):
    """Switch active LLM model."""
    if model not in model_router.MODELS:
        raise HTTPException(status_code=400, detail=f"Unknown model: {model}")

    model_path = f"./llama.cpp/models/{model_router.MODELS[model]}"
    llm_server.stop()
    llm_server.start(model_path)

    return {"model": model, "path": model_path, "status": "started"}

@app.get("/api/models/list")
async def list_models():
    """List available models."""
    return {
        "models": [
            {"id": k, "file": v, "path": f"./llama.cpp/models/{v}"}
            for k, v in model_router.MODELS.items()
        ],
        "active": llm_server.current_model
    }

# Static files (frontend build)
if os.path.exists("./frontend/dist"):
    app.mount("/", StaticFiles(directory="./frontend/dist", html=True), name="static")

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
