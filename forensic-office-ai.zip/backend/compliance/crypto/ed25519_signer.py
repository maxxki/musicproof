#!/usr/bin/env python3
"""
ed25519_signer.py
=================
Ed25519 signature wrapper with trust level management.
Replaces shared-secret HMAC with cryptographic identity.
"""

import os
import hashlib
import secrets
from typing import Optional, Tuple, Dict
from dataclasses import dataclass
from pathlib import Path

try:
    from cryptography.hazmat.primitives.asymmetric.ed25519 import (
        Ed25519PrivateKey, Ed25519PublicKey
    )
    from cryptography.hazmat.primitives import serialization
    from cryptography.exceptions import InvalidSignature
    CRYPTO_AVAILABLE = True
except ImportError:
    CRYPTO_AVAILABLE = False
    print("[WARN] cryptography library not available. Install: pip install cryptography")

try:
    from forensic_provenance.v1 import Ed25519Identity, Ed25519Signature, TrustLevel
    PROTOBUF_AVAILABLE = True
except ImportError:
    PROTOBUF_AVAILABLE = False


@dataclass(frozen=True)
class KeyMaterial:
    private_key: 'Ed25519PrivateKey'
    public_key: 'Ed25519PublicKey'
    trust_level: 'TrustLevel'
    key_fingerprint: bytes
    created_at_unix_ns: int


class Ed25519Signer:
    """
    Ed25519 signature manager with trust level hierarchy.

    Trust Levels:
        SOFTWARE_KEY (1): Software-generated, file-based storage
        TPM_SEALED (2): TPM/Secure Enclave protected
        HSM_PROTECTED (3): External HSM/Token (PKCS#11)
    """

    KEY_DIR = Path.home() / ".forensic_provenance" / "keys"
    KEY_FILE = KEY_DIR / "ed25519_software.key"

    def __init__(self, trust_level: TrustLevel = TrustLevel.TRUST_LEVEL_SOFTWARE_KEY):
        self.trust_level = trust_level
        self._key: Optional[KeyMaterial] = None
        self._init_key()

    def _init_key(self) -> None:
        if self.trust_level == TrustLevel.TRUST_LEVEL_SOFTWARE_KEY:
            self._key = self._load_or_create_software_key()
        elif self.trust_level == TrustLevel.TRUST_LEVEL_TPM_SEALED:
            self._key = self._load_tpm_key()
        elif self.trust_level == TrustLevel.TRUST_LEVEL_HSM_PROTECTED:
            self._key = self._load_hsm_key()
        else:
            raise ValueError(f"Unsupported trust level: {self.trust_level}")

    def _load_or_create_software_key(self) -> KeyMaterial:
        self.KEY_DIR.mkdir(parents=True, exist_ok=True, mode=0o700)
        if self.KEY_FILE.exists():
            with open(self.KEY_FILE, 'rb') as f:
                pem = f.read()
            private_key = serialization.load_pem_private_key(pem, password=None)
            public_key = private_key.public_key()
        else:
            private_key = Ed25519PrivateKey.generate()
            public_key = private_key.public_key()
            pem = private_key.private_bytes(
                encoding=serialization.Encoding.PEM,
                format=serialization.PrivateFormat.PKCS8,
                encryption_algorithm=serialization.NoEncryption()
            )
            with open(self.KEY_FILE, 'wb') as f:
                f.write(pem)
            os.chmod(self.KEY_FILE, 0o600)

        pub_bytes = public_key.public_bytes(
            encoding=serialization.Encoding.Raw,
            format=serialization.PublicFormat.Raw
        )
        fingerprint = hashlib.sha256(pub_bytes).digest()

        return KeyMaterial(
            private_key=private_key,
            public_key=public_key,
            trust_level=TrustLevel.TRUST_LEVEL_SOFTWARE_KEY,
            key_fingerprint=fingerprint,
            created_at_unix_ns=0
        )

    def _load_tpm_key(self) -> KeyMaterial:
        raise NotImplementedError("TPM/Secure Enclave support not yet implemented")

    def _load_hsm_key(self) -> KeyMaterial:
        raise NotImplementedError("HSM support not yet implemented")

    def get_identity(self) -> 'Ed25519Identity':
        pub_bytes = self._key.public_key.public_bytes(
            encoding=serialization.Encoding.Raw,
            format=serialization.PublicFormat.Raw
        )
        identity = Ed25519Identity()
        identity.public_key = pub_bytes
        identity.trust_level = self._key.trust_level
        identity.key_fingerprint = self._key.key_fingerprint
        return identity

    def sign(self, data: bytes) -> 'Ed25519Signature':
        data_hash = hashlib.sha256(data).digest()
        signature_bytes = self._key.private_key.sign(data_hash)
        sig = Ed25519Signature()
        sig.signature = signature_bytes
        sig.signer_public_key = self._key.public_key.public_bytes(
            encoding=serialization.Encoding.Raw,
            format=serialization.PublicFormat.Raw
        )
        sig.signed_at_unix_ns = 0
        sig.signed_hash = data_hash
        return sig

    def verify(self, data: bytes, signature: 'Ed25519Signature') -> bool:
        try:
            public_key = Ed25519PublicKey.from_public_bytes(signature.signer_public_key)
            public_key.verify(signature.signature, signature.signed_hash)
            expected_hash = hashlib.sha256(data).digest()
            if signature.signed_hash != expected_hash:
                return False
            return True
        except InvalidSignature:
            return False
        except Exception as e:
            print(f"[ERROR] Verification failed: {e}")
            return False


class TrustLevelManager:
    TRUST_LEVELS = {
        TrustLevel.TRUST_LEVEL_SOFTWARE_KEY: 1,
        TrustLevel.TRUST_LEVEL_TPM_SEALED: 2,
        TrustLevel.TRUST_LEVEL_HSM_PROTECTED: 3,
    }

    def __init__(self):
        self.signers: Dict[TrustLevel, Ed25519Signer] = {}

    def get_signer(self, min_trust_level: TrustLevel = TrustLevel.TRUST_LEVEL_SOFTWARE_KEY) -> Ed25519Signer:
        for level in [TrustLevel.TRUST_LEVEL_HSM_PROTECTED, TrustLevel.TRUST_LEVEL_TPM_SEALED, TrustLevel.TRUST_LEVEL_SOFTWARE_KEY]:
            if level in self.signers and self.TRUST_LEVELS[level] >= self.TRUST_LEVELS[min_trust_level]:
                return self.signers[level]
        if TrustLevel.TRUST_LEVEL_SOFTWARE_KEY not in self.signers:
            self.signers[TrustLevel.TRUST_LEVEL_SOFTWARE_KEY] = Ed25519Signer(TrustLevel.TRUST_LEVEL_SOFTWARE_KEY)
        return self.signers[TrustLevel.TRUST_LEVEL_SOFTWARE_KEY]

    def register_tpm(self) -> None:
        self.signers[TrustLevel.TRUST_LEVEL_TPM_SEALED] = Ed25519Signer(TrustLevel.TRUST_LEVEL_TPM_SEALED)

    def register_hsm(self, pkcs11_lib: str, slot: int, pin: str) -> None:
        raise NotImplementedError("HSM registration not yet implemented")


if __name__ == "__main__":
    if not CRYPTO_AVAILABLE:
        print("Install cryptography: pip install cryptography")
        exit(1)
    signer = Ed25519Signer(TrustLevel.TRUST_LEVEL_SOFTWARE_KEY)
    identity = signer.get_identity()
    print(f"Trust Level: {identity.trust_level}")
    print(f"Fingerprint: {identity.key_fingerprint.hex()}")
    test_data = b"Hello, Forensic World!"
    signature = signer.sign(test_data)
    print(f"Signature: {signature.signature.hex()[:32]}...")
    valid = signer.verify(test_data, signature)
    print(f"Valid: {valid}")
    invalid = signer.verify(b"Wrong data", signature)
    print(f"Invalid (wrong data): {invalid}")
