#!/usr/bin/env python3
"""
sensor_fusion.py
================
Korrelationsprüfung zwischen verschiedenen Sensor-Quellen.
Erkennt KI-Injektion durch Inkonsistenzen zwischen
MIDI-Daten, OS-Interrupts und Hardware-Events.
"""

import time
import statistics
from typing import List, Dict, Optional, Tuple
from dataclasses import dataclass, field
from collections import deque
from enum import Enum


class SensorType(Enum):
    MIDI_DRIVER = "midi_driver"
    OS_INTERRUPT = "os_interrupt"
    HARDWARE_IRQ = "hardware_irq"
    USB_URB = "usb_urb"
    KERNEL_TIMESTAMP = "kernel_timestamp"


@dataclass
class SensorEvent:
    """Ein Event von einem Sensor."""
    timestamp_ns: int
    sensor_type: SensorType
    source_id: str           # z.B. "midi0", "usb1-2", "irq16"
    raw_data: bytes
    metadata: Dict = field(default_factory=dict)


@dataclass
class CorrelationWindow:
    """Zeitfenster für Korrelationsanalyse."""
    start_ns: int
    end_ns: int
    events: List[SensorEvent] = field(default_factory=list)


class SensorFusionVerifier:
    """
    Verifiziert, dass Events aus verschiedenen Sensoren konsistent sind.

    Angriffsszenario:
        KI injiziert MIDI-Daten in den Treiber (source="midi"),
        aber es gibt keine passenden:
        - OS-Interrupts
        - USB-URBs (USB Request Blocks)
        - Hardware-IRQs
    """

    # Toleranzfenster: MIDI-Daten müssen innerhalb dieser Zeit
    # nach Hardware-Event auftreten
    MIDI_HARDWARE_LATENCY_MAX_MS = 5
    USB_POLLING_INTERVAL_MS = 1  # USB High-Speed = 1ms

    def __init__(self, window_size_ms: int = 100):
        self.window_size_ms = window_size_ms
        self.sensor_buffers: Dict[SensorType, deque] = {
            st: deque(maxlen=10000) for st in SensorType
        }
        self.correlation_violations: List[dict] = []

    def ingest(self, event: SensorEvent) -> None:
        """Nehme Sensor-Event auf."""
        self.sensor_buffers[event.sensor_type].append(event)

    def verify_midi_correlation(
        self,
        midi_timestamp_ns: int,
        device_id: str
    ) -> Tuple[bool, Dict]:
        """
        Prüfe, ob MIDI-Event korrelierte Hardware-Events hat.

        Returns:
            (valid, correlation_details)
        """
        window_start = midi_timestamp_ns - (self.MIDI_HARDWARE_LATENCY_MAX_MS * 1_000_000)
        window_end = midi_timestamp_ns + (self.MIDI_HARDWARE_LATENCY_MAX_MS * 1_000_000)

        details = {
            "midi_timestamp_ns": midi_timestamp_ns,
            "window_ms": self.MIDI_HARDWARE_LATENCY_MAX_MS,
            "correlated_events": {},
            "violations": [],
        }

        # 1. Prüfe USB-URBs (USB Request Blocks)
        # Jedes MIDI-Event muss einem USB-URB vorausgehen
        usb_urbs = self._get_events_in_window(SensorType.USB_URB, window_start, window_end)
        usb_for_device = [e for e in usb_urbs if device_id in e.source_id]

        details["correlated_events"]["usb_urbs"] = len(usb_for_device)
        if len(usb_for_device) == 0:
            details["violations"].append(
                f"No USB URB for {device_id} within {self.MIDI_HARDWARE_LATENCY_MAX_MS}ms"
            )

        # 2. Prüfe Hardware-IRQs
        hw_irqs = self._get_events_in_window(SensorType.HARDWARE_IRQ, window_start, window_end)
        irq_for_device = [e for e in hw_irqs if self._irq_matches_device(e, device_id)]

        details["correlated_events"]["hardware_irqs"] = len(irq_for_device)
        if len(irq_for_device) == 0:
            details["violations"].append(
                f"No Hardware IRQ for {device_id} within {self.MIDI_HARDWARE_LATENCY_MAX_MS}ms"
            )

        # 3. Prüfe OS-Interrupts
        os_irqs = self._get_events_in_window(SensorType.OS_INTERRUPT, window_start, window_end)
        os_for_device = [e for e in os_irqs if device_id in e.source_id]

        details["correlated_events"]["os_interrupts"] = len(os_for_device)
        if len(os_for_device) == 0:
            details["violations"].append(
                f"No OS interrupt for {device_id} within {self.MIDI_HARDWARE_LATENCY_MAX_MS}ms"
            )

        # 4. Prüfe zeitliche Konsistenz
        # MIDI-Daten dürfen nicht VOR dem USB-URB auftreten
        if usb_for_device:
            earliest_usb = min(e.timestamp_ns for e in usb_for_device)
            if midi_timestamp_ns < earliest_usb:
                details["violations"].append(
                    f"MIDI timestamp {midi_timestamp_ns} before USB URB {earliest_usb}"
                )

        valid = len(details["violations"]) == 0

        if not valid:
            self.correlation_violations.append(details)

        return valid, details

    def _get_events_in_window(
        self,
        sensor_type: SensorType,
        start_ns: int,
        end_ns: int
    ) -> List[SensorEvent]:
        """Hole Events eines Typs im Zeitfenster."""
        buffer = self.sensor_buffers[sensor_type]
        return [
            e for e in buffer
            if start_ns <= e.timestamp_ns <= end_ns
        ]

    def _irq_matches_device(self, irq_event: SensorEvent, device_id: str) -> bool:
        """Prüfe, ob IRQ-Event zu Gerät passt."""
        # In Produktion: IRQ-Nummer zu USB-Port-Mapping
        return device_id in irq_event.metadata.get("associated_devices", [])

    def detect_injection_pattern(self, events: List[SensorEvent]) -> Tuple[bool, Dict]:
        """
        Erkenne Muster, die auf KI-Injektion hindeuten.

        Anzeichen:
        - MIDI-Events ohne Hardware-Korrelat
        - Perfekte zeitliche Intervalle (Mensch = Jitter)
        - Keine USB-URB-Fragmentierung (echte USB = Fragmente)
        """
        midi_events = [e for e in events if e.sensor_type == SensorType.MIDI_DRIVER]

        if len(midi_events) < 2:
            return False, {"reason": "Too few events"}

        # Analyse 1: Inter-Event-Intervalle
        intervals = [
            (midi_events[i].timestamp_ns - midi_events[i-1].timestamp_ns) // 1_000_000
            for i in range(1, len(midi_events))
        ]

        # Menschliche Intervalle: Hohe Varianz (CV > 0.3)
        # KI-Injektion: Niedrige Varianz (CV < 0.1) oder perfekt periodisch
        if len(intervals) > 1:
            mean_interval = statistics.mean(intervals)
            std_interval = statistics.stdev(intervals) if len(intervals) > 1 else 0
            cv = std_interval / mean_interval if mean_interval > 0 else 0
        else:
            cv = 0

        # Analyse 2: USB-Fragmentierung
        # Echte USB-Übertragungen haben Fragmente (64-Byte-Pakete)
        # Injizierte Daten erscheinen als "magische" vollständige Pakete
        usb_events = [e for e in events if e.sensor_type == SensorType.USB_URB]
        fragment_ratio = len(usb_events) / max(len(midi_events), 1)

        # Normal: 2-5 USB-Events pro MIDI-Event (Fragmentierung + ACK)
        # Injiziert: 1:1 oder 0:1

        report = {
            "interval_cv": cv,
            "usb_fragment_ratio": fragment_ratio,
            "midi_events": len(midi_events),
            "usb_events": len(usb_events),
            "suspicious": False,
            "indicators": [],
        }

        # Suspicion thresholds
        if cv < 0.1 and len(intervals) > 5:
            report["suspicious"] = True
            report["indicators"].append("Too regular intervals (CV < 0.1)")

        if fragment_ratio < 0.5 and len(midi_events) > 3:
            report["suspicious"] = True
            report["indicators"].append("Insufficient USB fragmentation")

        return report["suspicious"], report

    def get_fusion_score(self, device_id: str, time_window_ms: int = 1000) -> float:
        """
        Berechne Fusion-Score (0.0 - 1.0) für ein Gerät.
        1.0 = Alle Sensoren korrelieren perfekt
        0.0 = Keine Korrelation (wahrscheinlich Injektion)
        """
        now = time.time_ns()
        window_start = now - (time_window_ms * 1_000_000)

        all_events = []
        for buffer in self.sensor_buffers.values():
            all_events.extend([
                e for e in buffer
                if e.timestamp_ns >= window_start and device_id in e.source_id
            ])

        if len(all_events) < 2:
            return 0.0

        # Score basiert auf:
        # - Anzahl korrelierter Sensor-Typen
        # - Zeitliche Konsistenz
        # - Varianz der Intervalle

        sensor_types_present = len(set(e.sensor_type for e in all_events))
        type_score = sensor_types_present / len(SensorType)

        # Zeitliche Konsistenz
        timestamps = sorted(e.timestamp_ns for e in all_events)
        if len(timestamps) > 1:
            max_gap = max(timestamps[i] - timestamps[i-1] for i in range(1, len(timestamps)))
            gap_score = 1.0 - min(max_gap / (10_000_000), 1.0)  # 10ms max gap
        else:
            gap_score = 0.0

        return (type_score * 0.6) + (gap_score * 0.4)


class KernelLogMonitor:
    """
    Überwacht Kernel-Logs auf Hardware-Events.
    Linux: /proc/kmsg, /dev/kmsg, dmesg
    """

    def __init__(self):
        self.irq_patterns = {
            "usb": b"usb",
            "midi": b"midi",
            "snd": b"snd",
        }

    def parse_kernel_message(self, msg: bytes) -> Optional[SensorEvent]:
        """Parse Kernel-Message zu SensorEvent."""
        timestamp_ns = time.time_ns()  # Approximation

        if b"irq" in msg.lower():
            return SensorEvent(
                timestamp_ns=timestamp_ns,
                sensor_type=SensorType.HARDWARE_IRQ,
                source_id="kernel_irq",
                raw_data=msg,
                metadata={"source": "kernel_log"}
            )

        if b"usb" in msg.lower():
            return SensorEvent(
                timestamp_ns=timestamp_ns,
                sensor_type=SensorType.USB_URB,
                source_id="kernel_usb",
                raw_data=msg,
                metadata={"source": "kernel_log"}
            )

        return None


# =============================================================================
# USAGE
# =============================================================================

if __name__ == "__main__":
    fusion = SensorFusionVerifier()

    # Simuliere echte Hardware-Events
    device = "midi0"
    now = time.time_ns()

    # USB-URB (muss VOR MIDI kommen)
    fusion.ingest(SensorEvent(
        timestamp_ns=now - 2_000_000,  # 2ms vor MIDI
        sensor_type=SensorType.USB_URB,
        source_id=f"usb-{device}",
        raw_data=b"USB-MIDI-DATA",
    ))

    # Hardware IRQ
    fusion.ingest(SensorEvent(
        timestamp_ns=now - 1_000_000,
        sensor_type=SensorType.HARDWARE_IRQ,
        source_id="irq16",
        raw_data=b"IRQ",
        metadata={"associated_devices": [device]}
    ))

    # OS Interrupt
    fusion.ingest(SensorEvent(
        timestamp_ns=now - 500_000,
        sensor_type=SensorType.OS_INTERRUPT,
        source_id=device,
        raw_data=b"OS-IRQ",
    ))

    # MIDI-Event
    fusion.ingest(SensorEvent(
        timestamp_ns=now,
        sensor_type=SensorType.MIDI_DRIVER,
        source_id=device,
        raw_data=b"\x90\x40\x7F",
    ))

    # Verifiziere
    valid, details = fusion.verify_midi_correlation(now, device)
    print(f"Correlation valid: {valid}")
    print(f"Details: {details}")

    # Fusion-Score
    score = fusion.get_fusion_score(device)
    print(f"Fusion score: {score:.2f}")
