#!/usr/bin/env python3
"""
noise_metrics.py
================
Rausch-Metriken und biologische Varianz-Analyse.
Erkennt KI-generierte Eingaben durch statistische Analyse
von Jitter, Latenz-Schwankungen und Entropie.
"""

import math
import statistics
import numpy as np
from typing import List, Dict, Tuple, Optional
from dataclasses import dataclass
from collections import deque


@dataclass
class NoiseProfile:
    """Statistisches Profil der biologischen Varianz."""
    jitter_mean_ms: float
    jitter_std_ms: float
    jitter_skewness: float
    jitter_kurtosis: float
    entropy_bits: float
    lyapunov_exponent: float
    hurst_exponent: float
    fractal_dimension: float
    is_biological: bool
    confidence: float


class BiologicalNoiseAnalyzer:
    """
    Analysiert "Rauschen" in menschlichen Eingaben.

    Menschliche Eingaben haben charakteristische Eigenschaften:
    - Jitter: Normalverteilt mit σ ≈ 50-150ms (neurologisch bedingt)
    - Tremor: 8-12 Hz, chaotisch, nicht-stationär
    - Backtracking: 20-40% der Aktionen
    - Entropie: Tsallis-Entropie ≈ 2.3-3.5 bits

    KI-generierte Eingaben:
    - Zu gleichmäßig (niedrige Varianz)
    - Zu perfekt randomisiert (hohe Entropie, aber falsche Verteilung)
    - Kein physiologischer Tremor
    - Keine nicht-lineare Dynamik (Lyapunov ≈ 0)
    """

    # Thresholds für biologische Eingaben
    JITTER_MEAN_MIN = 30.0      # ms
    JITTER_MEAN_MAX = 200.0     # ms
    JITTER_STD_MIN = 10.0       # ms
    JITTER_STD_MAX = 100.0      # ms
    ENTROPY_MIN = 2.0           # bits
    ENTROPY_MAX = 4.0           # bits
    LYAPUNOV_MIN = 0.1          # chaotisch
    LYAPUNOV_MAX = 2.0          # nicht zu chaotisch
    HURST_MIN = 0.3             # anti-persistent (menschlich)
    HURST_MAX = 0.7             # nicht zu persistent

    def __init__(self, history_size: int = 1000):
        self.history_size = history_size
        self.latency_history: deque = deque(maxlen=history_size)
        self.position_history: deque = deque(maxlen=history_size)
        self.tremor_buffer: deque = deque(maxlen=10000)

    def add_latency_sample(self, latency_ms: float) -> None:
        """Füge Latenz-Messung hinzu."""
        self.latency_history.append(latency_ms)

    def add_position_sample(self, position: float, timestamp_ns: int) -> None:
        """Füge Positions-Messung hinzu (für Tremor-Analyse)."""
        self.position_history.append((position, timestamp_ns))

    def analyze_jitter(self, latencies: List[float]) -> Dict:
        """
        Analysiere Jitter-Muster.

        Menschlicher Jitter:
        - Mittelwert: 50-150ms
        - Standardabweichung: 20-80ms
        - Schiefe: Leicht positiv (mehr kurze Latenzen)
        - Kurtosis: Leptokurtisch ("schwere Ränder")
        """
        if len(latencies) < 10:
            return {"error": "Too few samples"}

        mean = statistics.mean(latencies)
        std = statistics.stdev(latencies) if len(latencies) > 1 else 0

        # Schiefe (Skewness)
        n = len(latencies)
        skewness = sum((x - mean) ** 3 for x in latencies) / (n * std ** 3) if std > 0 else 0

        # Kurtosis
        kurtosis = sum((x - mean) ** 4 for x in latencies) / (n * std ** 4) - 3 if std > 0 else 0

        return {
            "mean_ms": mean,
            "std_ms": std,
            "skewness": skewness,
            "kurtosis": kurtosis,
            "cv": std / mean if mean > 0 else 0,
            "is_biological": (
                self.JITTER_MEAN_MIN <= mean <= self.JITTER_MEAN_MAX and
                self.JITTER_STD_MIN <= std <= self.JITTER_STD_MAX
            ),
        }

    def analyze_tremor(self, positions: List[Tuple[float, int]]) -> Dict:
        """
        Analysiere physiologischen Tremor (8-12 Hz).

        Menschlicher Tremor:
        - Frequenz: 8-12 Hz (physiologisch)
        - Amplitude: 0.5-2.0 mm (Finger), 1-3° (Handgelenk)
        - Dynamik: Chaotisch, nicht-stationär
        - Lyapunov-Exponent: > 0.1 (chaotisch)

        KI-simulierter Tremor:
        - Reine Sinuswelle oder perfektes Rauschen
        - Stationär (keine Zeitvarianz)
        - Lyapunov ≈ 0 (nicht chaotisch)
        """
        if len(positions) < 100:
            return {"error": "Too few samples for tremor analysis"}

        # Extrahiere Positionsdaten
        pos_values = [p[0] for p in positions]
        timestamps = [p[1] for p in positions]

        # Sampling-Rate berechnen
        dt = np.mean(np.diff(timestamps)) / 1e9  # in Sekunden
        fs = 1.0 / dt if dt > 0 else 1000

        # FFT für Frequenzanalyse
        fft = np.fft.fft(pos_values)
        freqs = np.fft.fftfreq(len(pos_values), d=dt)

        # Power Spectral Density
        psd = np.abs(fft) ** 2

        # Suche Tremor-Band (8-12 Hz)
        tremor_mask = (freqs >= 8) & (freqs <= 12)
        tremor_power = np.sum(psd[tremor_mask])
        total_power = np.sum(psd)
        tremor_ratio = tremor_power / total_power if total_power > 0 else 0

        # Dominante Frequenz im Tremor-Band
        if np.any(tremor_mask):
            dominant_idx = np.argmax(psd[tremor_mask])
            dominant_freq = freqs[tremor_mask][dominant_idx]
        else:
            dominant_freq = 0

        # Lyapunov-Exponent (Chaos-Maß)
        lyapunov = self._estimate_lyapunov(pos_values)

        # Hurst-Exponent (Persistenz)
        hurst = self._estimate_hurst(pos_values)

        # Fraktale Dimension
        fractal_dim = self._estimate_fractal_dimension(pos_values)

        return {
            "dominant_freq_hz": float(dominant_freq),
            "tremor_ratio": float(tremor_ratio),
            "lyapunov_exponent": float(lyapunov),
            "hurst_exponent": float(hurst),
            "fractal_dimension": float(fractal_dim),
            "is_biological": (
                8 <= dominant_freq <= 12 and
                self.LYAPUNOV_MIN <= lyapunov <= self.LYAPUNOV_MAX and
                self.HURST_MIN <= hurst <= self.HURST_MAX
            ),
        }

    def _estimate_lyapunov(self, data: List[float], tau: int = 1, dim: int = 3) -> float:
        """
        Schätze den größten Lyapunov-Exponenten.
        Positiver Wert = chaotisch (menschlich)
        Null oder negativ = nicht chaotisch (KI)
        """
        if len(data) < dim * tau + 100:
            return 0.0

        # Rekonstruiere Phasenraum
        embedded = np.array([
            [data[i + j * tau] for j in range(dim)]
            for i in range(len(data) - dim * tau)
        ])

        # Finde nächste Nachbarn
        n = len(embedded)
        divergences = []

        for i in range(n - 50):
            # Finde nächsten Nachbarn (nicht i selbst)
            distances = np.linalg.norm(embedded - embedded[i], axis=1)
            distances[i] = np.inf
            nearest = np.argmin(distances)

            # Verfolge Divergenz
            for k in range(1, min(50, n - max(i, nearest))):
                d0 = np.linalg.norm(embedded[i] - embedded[nearest])
                dk = np.linalg.norm(embedded[i + k] - embedded[nearest + k])
                if d0 > 0 and dk > 0:
                    divergences.append(np.log(dk / d0))

        if not divergences:
            return 0.0

        # Lineare Regression über Divergenzen
        # Steigung = Lyapunov-Exponent
        return np.mean(divergences) / tau if divergences else 0.0

    def _estimate_hurst(self, data: List[float]) -> float:
        """
        Schätze Hurst-Exponent via R/S-Analyse.
        H < 0.5: Anti-persistent (menschlich)
        H = 0.5: Random Walk
        H > 0.5: Persistent
        """
        if len(data) < 100:
            return 0.5

        data = np.array(data)
        n = len(data)

        # R/S-Analyse
        max_lag = min(n // 4, 100)
        lags = range(10, max_lag, 10)
        rs_values = []

        for lag in lags:
            # Teile in Chunks
            chunks = [data[i:i+lag] for i in range(0, n - lag, lag)]
            if len(chunks) < 2:
                continue

            rs_chunk = []
            for chunk in chunks:
                mean = np.mean(chunk)
                cumdev = np.cumsum(chunk - mean)
                r = np.max(cumdev) - np.min(cumdev)
                s = np.std(chunk)
                if s > 0:
                    rs_chunk.append(r / s)

            if rs_chunk:
                rs_values.append((lag, np.mean(rs_chunk)))

        if len(rs_values) < 2:
            return 0.5

        # Lineare Regression: log(R/S) vs log(lag)
        lags_log = np.log([x[0] for x in rs_values])
        rs_log = np.log([x[1] for x in rs_values])

        slope, _ = np.polyfit(lags_log, rs_log, 1)
        return slope

    def _estimate_fractal_dimension(self, data: List[float]) -> float:
        """
        Schätze fraktale Dimension via Box-Counting.
        Menschliche Bewegungen: 1.2 - 1.5
        KI-generiert: 1.0 (glatt) oder 2.0 (zu rau)
        """
        if len(data) < 100:
            return 1.0

        data = np.array(data)
        n = len(data)

        # Normalisiere
        data = (data - np.min(data)) / (np.max(data) - np.min(data))

        # Box-Counting
        scales = np.logspace(0.01, 1, 20)
        counts = []

        for scale in scales:
            boxes = int(1.0 / scale)
            if boxes < 1:
                continue

            # Zähle besetzte Boxen
            occupied = set()
            for i in range(n - 1):
                x = int(data[i] * boxes)
                y = int(data[i + 1] * boxes)
                occupied.add((x, y))

            counts.append((1.0 / scale, len(occupied)))

        if len(counts) < 2:
            return 1.0

        # Lineare Regression: log(N) vs log(1/scale)
        scales_log = np.log([x[0] for x in counts])
        counts_log = np.log([x[1] for x in counts])

        slope, _ = np.polyfit(scales_log, counts_log, 1)
        return slope

    def calculate_tsallis_entropy(self, data: List[float], q: float = 1.5) -> float:
        """
        Berechne Tsallis-Entropie (nicht-extensive).
        Bessere Metrik für biologische Systeme als Shannon-Entropie.
        """
        if not data:
            return 0.0

        # Histogramm
        hist, _ = np.histogram(data, bins=50, density=True)
        hist = hist[hist > 0]  # Entferne leere Bins

        if len(hist) == 0:
            return 0.0

        # Tsallis-Entropie: S_q = (1 - Σ p_i^q) / (q - 1)
        p = hist / np.sum(hist)
        entropy = (1.0 - np.sum(p ** q)) / (q - 1.0)

        return float(entropy)

    def generate_noise_profile(self) -> NoiseProfile:
        """Generiere komplettes Noise-Profil aus aktuellen Daten."""
        latencies = list(self.latency_history)
        positions = list(self.position_history)

        # Jitter-Analyse
        jitter = self.analyze_jitter(latencies) if len(latencies) >= 10 else {}

        # Tremor-Analyse
        tremor = self.analyze_tremor(positions) if len(positions) >= 100 else {}

        # Entropie
        entropy = self.calculate_tsallis_entropy(latencies) if latencies else 0

        # Bestimme, ob biologisch
        is_bio = (
            jitter.get("is_biological", False) and
            tremor.get("is_biological", False) and
            self.ENTROPY_MIN <= entropy <= self.ENTROPY_MAX
        )

        # Konfidenz
        confidence = 0.0
        if jitter.get("is_biological"):
            confidence += 0.3
        if tremor.get("is_biological"):
            confidence += 0.4
        if self.ENTROPY_MIN <= entropy <= self.ENTROPY_MAX:
            confidence += 0.3

        return NoiseProfile(
            jitter_mean_ms=jitter.get("mean_ms", 0),
            jitter_std_ms=jitter.get("std_ms", 0),
            jitter_skewness=jitter.get("skewness", 0),
            jitter_kurtosis=jitter.get("kurtosis", 0),
            entropy_bits=entropy,
            lyapunov_exponent=tremor.get("lyapunov_exponent", 0),
            hurst_exponent=tremor.get("hurst_exponent", 0.5),
            fractal_dimension=tremor.get("fractal_dimension", 1.0),
            is_biological=is_bio,
            confidence=confidence,
        )

    def detect_synthetic_input(self, profile: NoiseProfile) -> Tuple[bool, Dict]:
        """
        Erkenne synthetische (KI-generierte) Eingaben.

        Returns:
            (is_synthetic, detailed_analysis)
        """
        indicators = []

        # 1. Zu geringe Jitter-Varianz
        if profile.jitter_std_ms < self.JITTER_STD_MIN:
            indicators.append(f"Jitter too regular: {profile.jitter_std_ms:.1f}ms < {self.JITTER_STD_MIN}ms")

        # 2. Zu hohe Jitter-Varianz (absichtlich randomisiert)
        if profile.jitter_std_ms > self.JITTER_STD_MAX * 2:
            indicators.append(f"Jitter artificially high: {profile.jitter_std_ms:.1f}ms")

        # 3. Kein chaotischer Tremor
        if profile.lyapunov_exponent < self.LYAPUNOV_MIN:
            indicators.append(f"No chaotic tremor: Lyapunov={profile.lyapunov_exponent:.3f}")

        # 4. Zu hohe Entropie (perfektes Rauschen)
        if profile.entropy_bits > self.ENTROPY_MAX:
            indicators.append(f"Entropy too high: {profile.entropy_bits:.2f} bits")

        # 5. Zu niedrige Entropie (deterministisch)
        if profile.entropy_bits < self.ENTROPY_MIN / 2:
            indicators.append(f"Entropy too low: {profile.entropy_bits:.2f} bits")

        # 6. Hurst-Exponent (Persistenz)
        if profile.hurst_exponent > 0.8:
            indicators.append(f"Too persistent: H={profile.hurst_exponent:.3f}")
        if profile.hurst_exponent < 0.2:
            indicators.append(f"Too anti-persistent: H={profile.hurst_exponent:.3f}")

        is_synthetic = len(indicators) > 0

        return is_synthetic, {
            "is_synthetic": is_synthetic,
            "indicators": indicators,
            "profile": {
                "jitter_mean": profile.jitter_mean_ms,
                "jitter_std": profile.jitter_std_ms,
                "entropy": profile.entropy_bits,
                "lyapunov": profile.lyapunov_exponent,
                "hurst": profile.hurst_exponent,
                "fractal_dim": profile.fractal_dimension,
            },
            "confidence": profile.confidence,
        }


# =============================================================================
# USAGE
# =============================================================================

if __name__ == "__main__":
    analyzer = BiologicalNoiseAnalyzer()

    # Simuliere menschliche Latenzen (Normalverteilt, μ=100ms, σ=30ms)
    import random
    random.seed(42)
    for _ in range(100):
        latency = random.gauss(100, 30)
        analyzer.add_latency_sample(max(10, latency))

    # Simuliere menschliche Positionen (mit Tremor)
    import math
    t = 0
    for _ in range(1000):
        # Basis-Position + Tremor (8-12 Hz) + Rauschen
        pos = 0.5 + 0.1 * math.sin(2 * math.pi * 10 * t) + random.gauss(0, 0.02)
        analyzer.add_position_sample(pos, int(t * 1e9))
        t += 0.001  # 1ms Sampling

    # Generiere Profil
    profile = analyzer.generate_noise_profile()
    print(f"Is biological: {profile.is_biological}")
    print(f"Confidence: {profile.confidence:.2f}")
    print(f"Jitter: {profile.jitter_mean_ms:.1f} ± {profile.jitter_std_ms:.1f} ms")
    print(f"Entropy: {profile.entropy_bits:.2f} bits")
    print(f"Lyapunov: {profile.lyapunov_exponent:.3f}")
    print(f"Hurst: {profile.hurst_exponent:.3f}")

    # Prüfe auf synthetisch
    is_synthetic, analysis = analyzer.detect_synthetic_input(profile)
    print(f"
Is synthetic: {is_synthetic}")
    print(f"Indicators: {analysis['indicators']}")
