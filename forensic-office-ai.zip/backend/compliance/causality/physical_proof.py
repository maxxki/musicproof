#!/usr/bin/env python3
"""
physical_proof.py
=================
Integration aller Anti-Spoofing-Mechanismen.
Zentrale Schnittstelle für das ForensicLedger.
"""

import time
from typing import Dict, Tuple, Optional, List
from dataclasses import dataclass

from anti_replay_signature import (
    AntiReplaySigner, AntiReplayBinding, ReplayAttackDetector
)
from hardware_attestation import (
    HardwareAttestationOrchestrator, 
    AttestationResponse,
    SecureElementVerifier
)
from sensor_fusion import SensorFusionVerifier, SensorEvent, SensorType
from noise_metrics import BiologicalNoiseAnalyzer, NoiseProfile


@dataclass
class PhysicalProofBundle:
    """Kompletter Beweis-Bundle für eine menschliche Aktion."""
    hardware_attestation_passed: bool
    sensor_fusion_passed: bool
    noise_profile: Optional[NoiseProfile]
    is_synthetic: bool
    overall_confidence: float
    violations: List[str]
    timestamp_ns: int


class PhysicalProofValidator:
    """
    Validierungs-Orchestrator für PhysicalProof.

    Erweitert mit Anti-Replay-Binding:
    - Jede Validierung erzeugt ein frisches Nonce
    - Proof-Bundle ist kryptographisch an Edit-Event gebunden
    - Verhindert "Borrowing" von Proof-Bundles zwischen Events
    """
    """
    Validierungs-Orchestrator für PhysicalProof.

    Prüft ALLE Ebenen:
    1. Hardware-Attestation (Secure Element Signatur)
    2. Sensor-Fusion (OS-Interrupts + USB-URBs + Hardware-IRQs)
    3. Noise-Metriken (Jitter + Tremor + Entropie)
    4. Backtracking-Erkennung (Exploration vs. Optimierung)
    """

    MIN_CONFIDENCE_FOR_HUMAN = 0.75

    def __init__(self, private_key=None):
        self.hardware = HardwareAttestationOrchestrator()
        self.sensor_fusion = SensorFusionVerifier()
        self.noise = BiologicalNoiseAnalyzer()
        self.backtracking_history: List[dict] = []

        # Anti-Replay: Signiert Proof-Bundle + Edit-Event
        self.anti_replay = AntiReplaySigner(private_key) if private_key else None
        self.replay_detector = ReplayAttackDetector()

    def validate_human_action_with_binding(
        self,
        device_serial_hash: bytes,
        input_data: bytes,
        hardware_signature: bytes,
        edit_event=None,  # DAWEditEvent für Anti-Replay-Binding
        parameter_delta: Optional[dict] = None,
        tpm_response: Optional[AttestationResponse] = None
    ) -> Tuple[PhysicalProofBundle, Optional[AntiReplayBinding], Optional[bytes]]:
        """
        Validiere kompletten PhysicalProof MIT Anti-Replay-Binding.

        Returns:
            (bundle, binding, signature) — binding=None wenn Anti-Replay nicht verfügbar
        """
        violations = []

        # === EBENE 1-4: Gleiche Validierung wie vorher ===
        # ... (Hardware, Sensor, Noise, Backtracking)

        # [Rest der Validierung bleibt gleich, nur Rückgabe erweitert]

        # === ANTI-REPLAY BINDING ===
        binding = None
        signature = None

        if self.anti_replay and edit_event:
            signature, binding = self.anti_replay.create_binding(
                PhysicalProofBundle(
                    hardware_attestation_passed=hw_passed,
                    sensor_fusion_passed=sf_passed,
                    noise_profile=noise_profile,
                    is_synthetic=is_synthetic,
                    overall_confidence=confidence,
                    violations=violations,
                    timestamp_ns=time.time_ns(),
                ),
                edit_event
            )

            # Nonce-Replay-Check
            nonce_valid, nonce_reason = self.replay_detector.check_nonce(binding.nonce)
            if not nonce_valid:
                violations.append(f"REPLAY_ATTACK: {nonce_reason}")
                confidence = 0.0
                binding = None
                signature = None

        return PhysicalProofBundle(
            hardware_attestation_passed=hw_passed,
            sensor_fusion_passed=sf_passed,
            noise_profile=noise_profile,
            is_synthetic=is_synthetic,
            overall_confidence=confidence,
            violations=violations,
            timestamp_ns=time.time_ns(),
        ), binding, signature

    # Legacy: Ohne Anti-Replay
    def validate_human_action(
        self,
        device_serial_hash: bytes,
        input_data: bytes,
        hardware_signature: bytes,
        parameter_delta: Optional[dict] = None,
        tpm_response: Optional[AttestationResponse] = None
    ) -> PhysicalProofBundle:
        """
        Validiere kompletten PhysicalProof für eine Aktion.

        Returns:
            PhysicalProofBundle mit allen Prüfergebnissen
        """
        violations = []

        # === EBENE 1: Hardware-Attestation ===
        hw_passed, hw_report = self.hardware.full_attestation(
            device_serial_hash=device_serial_hash,
            input_data=input_data,
            signature=hardware_signature,
            tpm_response=tpm_response
        )

        if not hw_passed:
            violations.extend(hw_report.get("violations", []))

        # === EBENE 2: Sensor-Fusion ===
        # Ingest MIDI-Event
        midi_event = SensorEvent(
            timestamp_ns=time.time_ns(),
            sensor_type=SensorType.MIDI_DRIVER,
            source_id=f"midi-{device_serial_hash.hex()[:8]}",
            raw_data=input_data,
        )
        self.sensor_fusion.ingest(midi_event)

        sf_passed, sf_details = self.sensor_fusion.verify_midi_correlation(
            midi_timestamp_ns=time.time_ns(),
            device_id=f"midi-{device_serial_hash.hex()[:8]}"
        )

        if not sf_passed:
            violations.extend(sf_details.get("violations", []))

        # === EBENE 3: Noise-Metriken ===
        # Füge Latenz-Sample hinzu (Zeit seit letzter Aktion)
        # In Produktion: Echte Latenz messen
        self.noise.add_latency_sample(100.0)  # Stub

        noise_profile = self.noise.generate_noise_profile()
        is_synthetic, noise_analysis = self.noise.detect_synthetic_input(noise_profile)

        if is_synthetic:
            violations.extend(noise_analysis.get("indicators", []))

        # === EBENE 4: Backtracking-Erkennung ===
        if parameter_delta:
            backtracking_valid = self._verify_backtracking(parameter_delta)
            if not backtracking_valid:
                violations.append("No human backtracking detected (likely KI-optimization)")

        # === GESAMTBEWERTUNG ===
        confidence = self._calculate_overall_confidence(
            hw_passed=hw_passed,
            sf_passed=sf_passed,
            noise_profile=noise_profile,
            is_synthetic=is_synthetic,
            hw_report=hw_report,
            sf_details=sf_details,
        )

        return PhysicalProofBundle(
            hardware_attestation_passed=hw_passed,
            sensor_fusion_passed=sf_passed,
            noise_profile=noise_profile,
            is_synthetic=is_synthetic,
            overall_confidence=confidence,
            violations=violations,
            timestamp_ns=time.time_ns(),
        )

    def _verify_backtracking(self, parameter_delta: dict) -> bool:
        """
        Prüfe, ob Parameter-Änderungen menschliches Backtracking zeigen.

        Menschlich: 20-40% der Änderungen sind Rückschritte
        KI: Monoton oder perfekt optimiert
        """
        # In Produktion: Historie der Parameter-Änderungen vergleichen
        # Hier: Stub — immer True
        return True

    def _calculate_overall_confidence(
        self,
        hw_passed: bool,
        sf_passed: bool,
        noise_profile: Optional[NoiseProfile],
        is_synthetic: bool,
        hw_report: dict,
        sf_details: dict,
    ) -> float:
        """Berechne Gesamt-Konfidenz."""
        confidence = 0.0

        # Hardware-Attestation: 40%
        if hw_passed:
            confidence += 0.4

        # Sensor-Fusion: 30%
        if sf_passed:
            confidence += 0.3

        # Noise-Metriken: 30%
        if noise_profile and noise_profile.is_biological and not is_synthetic:
            confidence += 0.3
        elif noise_profile and noise_profile.confidence > 0.5:
            confidence += noise_profile.confidence * 0.3

        return min(confidence, 1.0)

    def is_human_verified(self, bundle: PhysicalProofBundle) -> bool:
        """Prüfe, ob Aktion als menschlich verifiziert gilt."""
        return (
            bundle.hardware_attestation_passed and
            bundle.sensor_fusion_passed and
            not bundle.is_synthetic and
            bundle.overall_confidence >= self.MIN_CONFIDENCE_FOR_HUMAN
        )


# =============================================================================
# INTEGRATION IN FORENSIC LEDGER
# =============================================================================

def enrich_event_with_physical_proof(
    event,  # DAWEditEvent
    proof_bundle: PhysicalProofBundle,
    validator: PhysicalProofValidator,
) -> None:
    """
    Erweitere DAWEditEvent mit PhysicalProof-Ergebnissen.

    Diese Funktion wird vom ForensicLedger aufgerufen,
    bevor ein Block appended wird.
    """
    # Setze SourceType basierend auf PhysicalProof
    if validator.is_human_verified(proof_bundle):
        event.causality.initiator.source_type = 1  # SOURCE_TYPE_HUMAN
        event.causality.executor.source_type = 1   # SOURCE_TYPE_HUMAN
        event.bgh_relevant = True
    else:
        event.causality.initiator.source_type = 5  # SOURCE_TYPE_EXTERNAL_DEVICE / UNVERIFIED
        event.causality.executor.source_type = 5
        event.bgh_relevant = False

    # Füge PhysicalProof-Metadaten hinzu
    event.metadata.physical_proof_confidence = proof_bundle.overall_confidence
    event.metadata.physical_proof_violations = proof_bundle.violations
    event.metadata.is_synthetic_detected = proof_bundle.is_synthetic

    # Noise-Profil (falls verfügbar)
    if proof_bundle.noise_profile:
        event.metadata.jitter_mean_ms = proof_bundle.noise_profile.jitter_mean_ms
        event.metadata.jitter_std_ms = proof_bundle.noise_profile.jitter_std_ms
        event.metadata.entropy_bits = proof_bundle.noise_profile.entropy_bits
        event.metadata.lyapunov_exponent = proof_bundle.noise_profile.lyapunov_exponent


# =============================================================================
# USAGE
# =============================================================================

if __name__ == "__main__":
    validator = PhysicalProofValidator()

    # Simuliere Validierung
    device_hash = b"\x01" * 32
    input_data = b"\x90\x40\x7F"
    signature = b"\x00" * 64  # Dummy — wird fehlschlagen

    bundle = validator.validate_human_action(
        device_serial_hash=device_hash,
        input_data=input_data,
        hardware_signature=signature,
    )

    print(f"Hardware attestation: {bundle.hardware_attestation_passed}")
    print(f"Sensor fusion: {bundle.sensor_fusion_passed}")
    print(f"Is synthetic: {bundle.is_synthetic}")
    print(f"Confidence: {bundle.overall_confidence:.2f}")
    print(f"Is human verified: {validator.is_human_verified(bundle)}")
    print(f"Violations: {bundle.violations}")
