#!/usr/bin/env python3
"""
engagement_state_machine.py
===========================
Tracks human engagement for forensic provenance.
Distinguishes creative human activity from automation/AI.
"""

import time
from enum import Enum, auto
from typing import Optional, Dict, List, Callable
from dataclasses import dataclass, field
from collections import deque

try:
    from noise_metrics import BiologicalNoiseAnalyzer, NoiseProfile
    NOISE_AVAILABLE = True
except ImportError:
    NOISE_AVAILABLE = False



class EngagementState(Enum):
    IDLE = 1
    ACTIVE = 2
    BACKGROUND_RENDER = 3
    EXPORT = 4
    AUTOMATION_PLAYBACK = 5
    AI_GENERATION = 6


@dataclass
class InputEvent:
    timestamp_ns: int
    source: str
    control_id: str
    value: float
    delta: float
    device_serial_hash: bytes


@dataclass
class StateTransition:
    from_state: EngagementState
    to_state: EngagementState
    timestamp_ns: int
    trigger_event: Optional[InputEvent]
    duration_in_previous_state_ms: int


class EngagementStateMachine:
    """
    Forensic engagement state machine.

    Rules:
        - IDLE → ACTIVE: Any human input event
        - ACTIVE → IDLE: No input for 10 seconds
        - ACTIVE → BACKGROUND_RENDER: Explicit render command
        - Any → AI_GENERATION: AI generation started
        - AI_GENERATION → ACTIVE: Human overrides AI
        - Any → EXPORT: Export initiated
    """

    IDLE_TIMEOUT_MS = 10_000
    ACTIVE_HISTORY_SIZE = 1000

    def __init__(self):
        self.state = EngagementState.ENGAGEMENT_STATE_IDLE
        self.state_entered_ns = time.time_ns()
        self.last_input_ns = 0
        self.input_history: deque = deque(maxlen=self.ACTIVE_HISTORY_SIZE)
        self.transition_history: List[StateTransition] = []
        self._callbacks: List[Callable[[StateTransition], None]] = []
        self.noise_analyzer = BiologicalNoiseAnalyzer() if NOISE_AVAILABLE else None


    def register_callback(self, callback: Callable[[StateTransition], None]) -> None:
        self._callbacks.append(callback)

    def on_input(self, event: InputEvent) -> StateTransition:
        self.input_history.append(event)
        self.last_input_ns = event.timestamp_ns
        if self.state in (EngagementState.ENGAGEMENT_STATE_IDLE, EngagementState.ENGAGEMENT_STATE_AI_GENERATION, 
                         EngagementState.ENGAGEMENT_STATE_AUTOMATION_PLAYBACK):
            return self._transition_to(EngagementState.ENGAGEMENT_STATE_ACTIVE, event)
        return None

    def on_ai_generation_start(self) -> StateTransition:
        if self.state != EngagementState.ENGAGEMENT_STATE_AI_GENERATION:
            return self._transition_to(EngagementState.ENGAGEMENT_STATE_AI_GENERATION, None)
        return None

    def on_ai_generation_end(self) -> Optional[StateTransition]:
        if self.state == EngagementState.ENGAGEMENT_STATE_AI_GENERATION:
            return self._transition_to(EngagementState.ENGAGEMENT_STATE_IDLE, None)
        return None

    def on_automation_start(self) -> StateTransition:
        if self.state != EngagementState.ENGAGEMENT_STATE_AUTOMATION_PLAYBACK:
            return self._transition_to(EngagementState.ENGAGEMENT_STATE_AUTOMATION_PLAYBACK, None)
        return None

    def on_export(self) -> StateTransition:
        return self._transition_to(EngagementState.ENGAGEMENT_STATE_EXPORT, None)

    def check_timeout(self, current_time_ns: int) -> Optional[StateTransition]:
        if self.state == EngagementState.ENGAGEMENT_STATE_ACTIVE:
            elapsed_ms = (current_time_ns - self.last_input_ns) // 1_000_000
            if elapsed_ms > self.IDLE_TIMEOUT_MS:
                return self._transition_to(EngagementState.ENGAGEMENT_STATE_IDLE, None)
        return None

    def _transition_to(self, new_state: EngagementState, 
                      trigger: Optional[InputEvent]) -> StateTransition:
        now = time.time_ns()
        duration_ms = (now - self.state_entered_ns) // 1_000_000

        transition = StateTransition(
            from_state=self.state,
            to_state=new_state,
            timestamp_ns=now,
            trigger_event=trigger,
            duration_in_previous_state_ms=duration_ms
        )

        self.transition_history.append(transition)
        self.state = new_state
        self.state_entered_ns = now

        for cb in self._callbacks:
            cb(transition)

        return transition

    def get_forensic_summary(self) -> Dict:
        total_active_ms = sum(
            t.duration_in_previous_state_ms 
            for t in self.transition_history 
            if t.from_state == EngagementState.ENGAGEMENT_STATE_ACTIVE
        )

        total_ai_ms = sum(
            t.duration_in_previous_state_ms
            for t in self.transition_history
            if t.from_state == EngagementState.ENGAGEMENT_STATE_AI_GENERATION
        )

        human_events = len([
            e for e in self.input_history 
            if e.source in ("midi", "mouse", "keyboard", "touch", "pen")
        ])

        return {
            "total_active_duration_ms": total_active_ms,
            "total_ai_generation_duration_ms": total_ai_ms,
            "human_input_events": human_events,
            "state_transitions": len(self.transition_history),
            "current_state": self.state.name,
            "bgh_relevant": self.state == EngagementState.ENGAGEMENT_STATE_ACTIVE and total_active_ms > 300_000,
            "ai_dominant": total_ai_ms > total_active_ms * 2
        }


if __name__ == "__main__":
    sm = EngagementStateMachine()
    event = InputEvent(
        timestamp_ns=time.time_ns(),
        source="midi",
        control_id="Knob_4",
        value=0.75,
        delta=0.05,
        device_serial_hash=b'\x01' * 32
    )
    transition = sm.on_input(event)
    print(f"State: {sm.state.name}")
    print(f"Transition: {transition.from_state.name} -> {transition.to_state.name}")
    sm.on_ai_generation_start()
    print(f"State after AI start: {sm.state.name}")
    sm.on_ai_generation_end()
    print(f"State after AI end: {sm.state.name}")
    summary = sm.get_forensic_summary()
    print(f"Summary: {summary}")
