#!/usr/bin/env python3
"""
hardware_attestation.py
=======================
Remote Attestation + Secure Element Verification.
Beweist, dass Eingabedaten direkt von physischem USB-Controller kommen,
nicht von virtuellem Treiber oder KI-Injektion.
"""

import hashlib
import hmac
import os
import time
from typing import Dict, Optional, Tuple, List
from dataclasses import dataclass
from enum import Enum
from pathlib import Path

try:
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
    from cryptography.exceptions import InvalidSignature
    CRYPTO_AVAILABLE = True
except ImportError:
    CRYPTO_AVAILABLE = False


class AttestationError(Exception):
    """Raised when hardware attestation fails."""
    pass


@dataclass(frozen=True)
class AttestationChallenge:
    """Challenge-Response für Remote Attestation."""
    nonce: bytes
    timestamp_ns: int
    session_binding: bytes
    expected_device_type: str


@dataclass
class AttestationResponse:
    """Antwort des Secure Elements."""
    device_serial_hash: bytes
    device_type: str
    quote: bytes
    signature: bytes
    measurement: bytes
    pcr_values: Dict[int, bytes]


class TPMQuoteVerifier:
    """
    Verifiziert TPM-Quotes (Trusted Platform Module).
    Beweist, dass das OS nicht kompromittiert ist.
    """

    PCR_EXPECTED = {
        0: "BIOS",           # BIOS/UEFI
        1: "MBR",            # Bootloader
        2: "OS_LOADER",      # OS Loader
        3: "OS",             # OS Kernel
        7: "SECURE_BOOT",    # Secure Boot Policy
    }

    def __init__(self, ak_public_key: bytes):
        """
        Args:
            ak_public_key: Attestation Key Public Key (PEM oder raw)
        """
        self.ak_public_key = ak_public_key
        self.expected_pcr_values: Dict[int, bytes] = {}

    def register_expected_pcr(self, pcr_index: int, expected_value: bytes) -> None:
        """Registriere erwarteten PCR-Wert (aus "Golden Image")."""
        if len(expected_value) != 32:
            raise ValueError("PCR value must be 32 bytes (SHA-256)")
        self.expected_pcr_values[pcr_index] = expected_value

    def verify_quote(self, response: AttestationResponse) -> Tuple[bool, List[str]]:
        """
        Verifiziere TPM-Quote.

        Returns:
            (valid, list_of_violations)
        """
        violations = []

        # 1. Verifiziere Signatur über Quote
        try:
            pubkey = Ed25519PublicKey.from_public_bytes(self.ak_public_key)
            pubkey.verify(response.signature, response.quote)
        except InvalidSignature:
            violations.append("TPM quote signature invalid")
            return False, violations
        except Exception as e:
            violations.append(f"Signature verification error: {e}")
            return False, violations

        # 2. Prüfe PCR-Werte gegen "Golden Image"
        for pcr_idx, expected in self.expected_pcr_values.items():
            actual = response.pcr_values.get(pcr_idx)
            if actual is None:
                violations.append(f"PCR[{pcr_idx}] missing in quote")
            elif actual != expected:
                violations.append(
                    f"PCR[{pcr_idx}] mismatch: expected {expected.hex()[:16]}..., "
                    f"got {actual.hex()[:16]}..."
                )

        # 3. Prüfe, dass Session-Binding im Quote enthalten ist
        # (verhindert Replay-Angriffe)
        if not self._verify_session_binding(response):
            violations.append("Session binding mismatch - possible replay attack")

        valid = len(violations) == 0
        return valid, violations

    def _verify_session_binding(self, response: AttestationResponse) -> bool:
        """Verifiziere, dass Quote an aktuelle Session gebunden ist."""
        # In Produktion: Session-Nonce im Quote prüfen
        return True  # Stub


class SecureElementVerifier:
    """
    Verifiziert Secure-Element-Signaturen (z.B. ATECC608A im MIDI-Controller).
    Jedes physikalische Control-Element hat einen eingebauten 
    kryptographischen Schlüssel, der nicht extrahiert werden kann.
    """

    def __init__(self):
        self.trusted_devices: Dict[bytes, bytes] = {}
        # trusted_devices[device_serial_hash] = public_key

    def register_device(self, device_serial_hash: bytes, public_key: bytes) -> None:
        """Registriere vertrauenswürdiges Gerät (beim ersten Pairing)."""
        if len(device_serial_hash) != 32:
            raise ValueError("Device serial hash must be 32 bytes")
        if len(public_key) != 32:
            raise ValueError("Ed25519 public key must be 32 bytes")
        self.trusted_devices[device_serial_hash] = public_key

    def verify_input_signature(
        self,
        device_serial_hash: bytes,
        input_data: bytes,
        signature: bytes
    ) -> bool:
        """
        Verifiziere, dass Eingabe vom physischen Gerät signiert wurde.

        Args:
            device_serial_hash: SHA-256 der anonymisierten Seriennummer
            input_data: Die rohen Eingabedaten (z.B. MIDI-Bytes)
            signature: Ed25519-Signatur über input_data

        Returns:
            True wenn Signatur gültig und Gerät vertrauenswürdig
        """
        if device_serial_hash not in self.trusted_devices:
            return False

        pubkey_bytes = self.trusted_devices[device_serial_hash]

        try:
            pubkey = Ed25519PublicKey.from_public_bytes(pubkey_bytes)
            pubkey.verify(signature, hashlib.sha256(input_data).digest())
            return True
        except InvalidSignature:
            return False
        except Exception:
            return False

    def generate_challenge(self, device_serial_hash: bytes) -> AttestationChallenge:
        """Generiere Challenge für Live-Attestation."""
        nonce = os.urandom(32)
        session_binding = hashlib.sha256(
            device_serial_hash + nonce + str(time.time_ns()).encode()
        ).digest()

        return AttestationChallenge(
            nonce=nonce,
            timestamp_ns=time.time_ns(),
            session_binding=session_binding,
            expected_device_type="MIDI_CONTROLLER"
        )

    def verify_challenge_response(
        self,
        challenge: AttestationChallenge,
        response: AttestationResponse
    ) -> bool:
        """
        Verifiziere, dass Gerät Challenge korrekt beantwortet hat.
        Verhindert Replay-Angriffe.
        """
        # 1. Prüfe Zeitfenster (Challenge gültig für 30 Sekunden)
        elapsed_ms = (time.time_ns() - challenge.timestamp_ns) // 1_000_000
        if elapsed_ms > 30_000:
            return False

        # 2. Prüfe Session-Binding
        expected_binding = hashlib.sha256(
            response.device_serial_hash + challenge.nonce + 
            str(challenge.timestamp_ns).encode()
        ).digest()

        # 3. Verifiziere Signatur über Challenge
        challenge_data = challenge.nonce + challenge.session_binding
        return self.verify_input_signature(
            response.device_serial_hash,
            challenge_data,
            response.signature
        )


class USBTopologyVerifier:
    """
    Verifiziert USB-Topologie: Ist das Gerät wirklich physisch angeschlossen
    oder ein virtueller Treiber (z.B. loopMIDI, virtualMIDI)?
    """

    VIRTUAL_DRIVER_PATTERNS = [
        b"loopMIDI",
        b"virtualMIDI",
        b"rtpMIDI",
        b"VMware",
        b"VirtualBox",
        b"Parallels",
    ]

    def __init__(self):
        self.verified_buses: Dict[str, dict] = {}

    def scan_usb_topology(self) -> Dict[str, dict]:
        """
        Scannt USB-Bus-Topologie (Linux: /sys/bus/usb/devices/).
        Gibt physikalische Bus-Struktur zurück.
        """
        topology = {}

        # Linux USB sysfs
        usb_path = Path("/sys/bus/usb/devices")
        if usb_path.exists():
            for device_dir in usb_path.iterdir():
                if not device_dir.is_dir():
                    continue

                try:
                    vendor = (device_dir / "idVendor").read_text().strip()
                    product = (device_dir / "idProduct").read_text().strip()
                    manufacturer = (device_dir / "manufacturer").read_text().strip()

                    # Prüfe auf virtuelle Treiber
                    is_virtual = any(
                        pattern in manufacturer.encode() 
                        for pattern in self.VIRTUAL_DRIVER_PATTERNS
                    )

                    topology[device_dir.name] = {
                        "vendor": vendor,
                        "product": product,
                        "manufacturer": manufacturer,
                        "is_virtual": is_virtual,
                        "bus": (device_dir / "busnum").read_text().strip() if (device_dir / "busnum").exists() else "unknown",
                    }
                except (PermissionError, FileNotFoundError):
                    continue

        return topology

    def verify_physical_presence(self, device_serial_hash: bytes) -> Tuple[bool, str]:
        """
        Prüfe, ob Gerät physisch am USB-Bus hängt (nicht virtuell).

        Returns:
            (is_physical, reason)
        """
        topology = self.scan_usb_topology()

        for device_id, info in topology.items():
            if info.get("is_virtual"):
                return False, f"Device {device_id} uses virtual driver: {info['manufacturer']}"

        # Prüfe, dass Gerät auf echtem USB-Hub (nicht Root-Hub) hängt
        # Root-Hubs können von VMs emuliert werden
        # Echte Hubs haben eine Tiefe > 0

        return True, "Physical USB device detected"


class HardwareAttestationOrchestrator:
    """
    Orchestriert alle Attestations-Prüfungen.
    Zentrale Schnittstelle für das ForensicLedger.
    """

    def __init__(self):
        self.tpm_verifier = TPMQuoteVerifier(b"")  # Stub
        self.se_verifier = SecureElementVerifier()
        self.usb_verifier = USBTopologyVerifier()
        self.attestation_history: List[dict] = []

    def full_attestation(
        self,
        device_serial_hash: bytes,
        input_data: bytes,
        signature: bytes,
        tpm_response: Optional[AttestationResponse] = None
    ) -> Tuple[bool, Dict]:
        """
        Führe komplette Hardware-Attestation durch.

        Returns:
            (passed, detailed_report)
        """
        report = {
            "timestamp_ns": time.time_ns(),
            "device_serial_hash": device_serial_hash.hex()[:16] + "...",
            "checks": {},
            "violations": [],
        }

        # 1. Secure Element Signatur
        se_valid = self.se_verifier.verify_input_signature(
            device_serial_hash, input_data, signature
        )
        report["checks"]["secure_element_signature"] = se_valid
        if not se_valid:
            report["violations"].append("Secure Element signature invalid")

        # 2. USB-Topologie (physisch vs. virtuell)
        usb_valid, usb_reason = self.usb_verifier.verify_physical_presence(device_serial_hash)
        report["checks"]["usb_physical"] = usb_valid
        report["checks"]["usb_reason"] = usb_reason
        if not usb_valid:
            report["violations"].append(f"USB topology: {usb_reason}")

        # 3. TPM Quote (falls verfügbar)
        if tpm_response:
            tpm_valid, tpm_violations = self.tpm_verifier.verify_quote(tpm_response)
            report["checks"]["tpm_quote"] = tpm_valid
            report["checks"]["tpm_violations"] = tpm_violations
            if not tpm_valid:
                report["violations"].extend(tpm_violations)
        else:
            report["checks"]["tpm_quote"] = "skipped"

        # 4. Challenge-Response (Anti-Replay)
        challenge = self.se_verifier.generate_challenge(device_serial_hash)
        # In Produktion: Challenge an Gerät senden und Response verifizieren
        report["checks"]["challenge_generated"] = True

        passed = len(report["violations"]) == 0
        report["overall_passed"] = passed

        self.attestation_history.append(report)

        return passed, report


# =============================================================================
# USAGE
# =============================================================================

if __name__ == "__main__":
    # Demo: Registriere ein MIDI-Keyboard
    orchestrator = HardwareAttestationOrchestrator()

    # Simuliere Gerät-Registrierung (beim ersten Pairing)
    device_hash = b"\x01" * 32
    device_pubkey = b"\x02" * 32  # In echt: Aus Secure-Element ausgelesen
    orchestrator.se_verifier.register_device(device_hash, device_pubkey)

    # Simuliere Eingabe
    midi_data = b"\x90\x40\x7F"  # Note On, C4, Velocity 127

    # In echt: Signatur vom Secure-Element
    # Hier: Dummy (wird fehlschlagen, da keine echte Signatur)
    dummy_signature = b"\x00" * 64

    passed, report = orchestrator.full_attestation(
        device_serial_hash=device_hash,
        input_data=midi_data,
        signature=dummy_signature
    )

    print(f"Attestation passed: {passed}")
    print(f"Report: {report}")
