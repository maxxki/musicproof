#!/usr/bin/env python3
"""
anti_replay_signature.py
========================
Anti-Replay Signatur-Wrapper für PhysicalProof + EditEvent Binding.

Kernidee:
    Die Signatur wird über einen kombinierten Hash gebildet:
    H_combined = SHA256( H_proof_bundle || H_edit_event || nonce )

    Dadurch ist das Proof-Bundle an ein spezifisches Edit-Event gebunden.
    Ein "geliehenes" Proof-Bundle von einem anderen Event verifiziert nicht.

Angriffsszenario, das dies verhindert:
    1. Legitimes Event A mit gültigem PhysicalProof wird signiert
    2. Angreifer kopiert Proof-Bundle von Event A
    3. Angreifer erzeugt gefälschtes Event B
    4. Angreifer setzt Proof-Bundle von A auf Event B
    5. OHNE Anti-Replay: Verifizierung schlägt fehl, da H_edit_event unterschiedlich
"""

import hashlib
import os
import time
from typing import Tuple, Optional
from dataclasses import dataclass

try:
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
    CRYPTO_AVAILABLE = True
except ImportError:
    CRYPTO_AVAILABLE = False

from physical_proof import PhysicalProofBundle
from canonical_validator import CanonicalValidator


@dataclass(frozen=True)
class AntiReplayBinding:
    """Die kryptographische Bindung zwischen Proof und Event."""
    combined_hash: bytes      # SHA256( proof_hash || event_hash || nonce )
    proof_bundle_hash: bytes  # SHA256( serialized proof bundle )
    edit_event_hash: bytes    # SHA256( canonical edit event )
    nonce: bytes             # 32 Bytes frisches Nonce pro Signatur
    timestamp_ns: int        # Zeitstempel der Bindung


class AntiReplaySigner:
    """
    Erzeugt Anti-Replay-Signaturen über PhysicalProof + EditEvent.
    """

    NONCE_SIZE = 32
    HASH_SIZE = 32

    def __init__(self, private_key: Ed25519PrivateKey):
        self.private_key = private_key
        self.validator = CanonicalValidator()

    def create_binding(
        self,
        proof_bundle: PhysicalProofBundle,
        edit_event,  # DAWEditEvent (protobuf)
    ) -> Tuple[bytes, AntiReplayBinding]:
        """
        Erzeuge kryptographische Bindung und signiere.

        Returns:
            (signature_bytes, binding_metadata)
        """
        # 1. Serialisiere Proof-Bundle deterministisch
        proof_hash = self._hash_proof_bundle(proof_bundle)

        # 2. Canonical Hash des Edit-Events
        event_hash = self.validator.compute_hash(edit_event)

        # 3. Frisches Nonce (verhindert Replay SELBST bei identischen Events)
        nonce = os.urandom(self.NONCE_SIZE)

        # 4. Kombinierter Hash
        combined = hashlib.sha256(
            proof_hash + event_hash + nonce
        ).digest()

        # 5. Signiere kombinierten Hash
        signature = self.private_key.sign(combined)

        binding = AntiReplayBinding(
            combined_hash=combined,
            proof_bundle_hash=proof_hash,
            edit_event_hash=event_hash,
            nonce=nonce,
            timestamp_ns=time.time_ns(),
        )

        return signature, binding

    def verify_binding(
        self,
        signature: bytes,
        binding: AntiReplayBinding,
        proof_bundle: PhysicalProofBundle,
        edit_event,  # DAWEditEvent
        public_key_bytes: bytes,
    ) -> bool:
        """
        Verifiziere, dass Signatur über korrekte Bindung gilt.

        Prüft:
        1. Proof-Bundle-Hash stimmt mit aktuellem Bundle überein
        2. Edit-Event-Hash stimmt mit aktuellem Event überein
        3. Kombinierter Hash ist korrekt gebildet
        4. Signatur ist gültig
        """
        from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
        from cryptography.exceptions import InvalidSignature

        # 1. Rekonstruiere Proof-Bundle-Hash
        current_proof_hash = self._hash_proof_bundle(proof_bundle)
        if current_proof_hash != binding.proof_bundle_hash:
            return False

        # 2. Rekonstruiere Edit-Event-Hash
        current_event_hash = self.validator.compute_hash(edit_event)
        if current_event_hash != binding.edit_event_hash:
            return False

        # 3. Rekonstruiere kombinierten Hash
        reconstructed = hashlib.sha256(
            binding.proof_bundle_hash + binding.edit_event_hash + binding.nonce
        ).digest()
        if reconstructed != binding.combined_hash:
            return False

        # 4. Verifiziere Signatur
        try:
            public_key = Ed25519PublicKey.from_public_bytes(public_key_bytes)
            public_key.verify(signature, binding.combined_hash)
            return True
        except InvalidSignature:
            return False
        except Exception:
            return False

    def _hash_proof_bundle(self, bundle: PhysicalProofBundle) -> bytes:
        """Deterministischer Hash über PhysicalProofBundle."""
        # Serialisiere alle relevanten Felder
        data = b""
        data += (b"\x01" if bundle.hardware_attestation_passed else b"\x00")
        data += (b"\x01" if bundle.sensor_fusion_passed else b"\x00")
        data += (b"\x01" if bundle.is_synthetic else b"\x00")
        data += struct.pack("<f", bundle.overall_confidence)

        # Violations (sortiert für Determinismus)
        for v in sorted(bundle.violations):
            data += v.encode('utf-8')

        # Noise-Profil (falls vorhanden)
        if bundle.noise_profile:
            np = bundle.noise_profile
            data += struct.pack("<f", np.jitter_mean_ms)
            data += struct.pack("<f", np.jitter_std_ms)
            data += struct.pack("<f", np.entropy_bits)
            data += struct.pack("<f", np.lyapunov_exponent)
            data += struct.pack("<f", np.hurst_exponent)
            data += struct.pack("<f", np.fractal_dimension)
            data += (b"\x01" if np.is_biological else b"\x00")

        data += struct.pack("<q", bundle.timestamp_ns)

        return hashlib.sha256(data).digest()


class ReplayAttackDetector:
    """
    Erkennt Replay-Angriffe durch Nonce-Tracking.
    """

    def __init__(self, max_nonce_age_seconds: int = 300):
        self.seen_nonces: set = set()
        self.nonce_timestamps: dict = {}
        self.max_age = max_nonce_age_seconds

    def check_nonce(self, nonce: bytes) -> Tuple[bool, str]:
        """
        Prüfe, ob Nonce bereits verwendet wurde.

        Returns:
            (valid, reason)
        """
        # Cleanup alte Nonces
        now = time.time()
        expired = [
            n for n, ts in self.nonce_timestamps.items()
            if (now - ts) > self.max_age
        ]
        for n in expired:
            self.seen_nonces.discard(n)
            del self.nonce_timestamps[n]

        # Prüfe Nonce
        if nonce in self.seen_nonces:
            return False, f"Nonce replay detected: {nonce.hex()[:16]}..."

        # Registriere Nonce
        self.seen_nonces.add(nonce)
        self.nonce_timestamps[nonce] = now

        return True, "fresh"

    def get_stats(self) -> dict:
        """Statistik über Nonce-Tracking."""
        return {
            "active_nonces": len(self.seen_nonces),
            "max_age_seconds": self.max_age,
        }


# =============================================================================
# INTEGRATION: Erweiterter PhysicalProofValidator
# =============================================================================

class AntiReplayPhysicalProofValidator:
    """
    Erweiterter Validator mit Anti-Replay-Binding.

    Verwendung im ForensicLedger:
        1. PhysicalProofBundle erstellen
        2. Anti-Replay-Binding erstellen
        3. Beides im TrustAnchor speichern
        4. Verifizierung prüft BEIDE Hashes
    """

    def __init__(self, private_key: Ed25519PrivateKey):
        self.proof_validator = PhysicalProofValidator()
        self.anti_replay = AntiReplaySigner(private_key)
        self.replay_detector = ReplayAttackDetector()

    def validate_and_bind(
        self,
        device_serial_hash: bytes,
        input_data: bytes,
        hardware_signature: bytes,
        edit_event,
        public_key_bytes: bytes,
    ) -> Tuple[PhysicalProofBundle, Optional[AntiReplayBinding], bytes]:
        """
        Validiere PhysicalProof UND erstelle Anti-Replay-Binding.

        Returns:
            (proof_bundle, binding, signature)
        """
        # 1. PhysicalProof validieren
        bundle = self.proof_validator.validate_human_action(
            device_serial_hash=device_serial_hash,
            input_data=input_data,
            hardware_signature=hardware_signature,
        )

        # 2. Anti-Replay-Binding erstellen
        signature, binding = self.anti_replay.create_binding(bundle, edit_event)

        # 3. Nonce-Replay prüfen
        nonce_valid, nonce_reason = self.replay_detector.check_nonce(binding.nonce)
        if not nonce_valid:
            # Nonce wurde bereits verwendet → potenzieller Replay-Angriff
            bundle.violations.append(f"REPLAY_ATTACK: {nonce_reason}")
            bundle.overall_confidence = 0.0
            return bundle, None, b""

        # 4. Verifizierung (Self-Check)
        if not self.anti_replay.verify_binding(
            signature, binding, bundle, edit_event, public_key_bytes
        ):
            bundle.violations.append("ANTI_REPLAY_SELF_CHECK_FAILED")
            bundle.overall_confidence = 0.0
            return bundle, None, b""

        return bundle, binding, signature


# =============================================================================
# USAGE
# =============================================================================

if __name__ == "__main__":
    if not CRYPTO_AVAILABLE:
        print("Install cryptography: pip install cryptography")
        exit(1)

    # Demo: Erzeuge Schlüsselpaar
    private_key = Ed25519PrivateKey.generate()
    public_key = private_key.public_key()
    public_bytes = public_key.public_bytes(
        encoding=serialization.Encoding.Raw,
        format=serialization.PublicFormat.Raw
    )

    # Erstelle Validator
    validator = AntiReplayPhysicalProofValidator(private_key)

    # Simuliere Event (Stub)
    from forensic_provenance.v1 import DAWEditEvent
    event = DAWEditEvent()
    event.event_id = "test-123"
    event.sequence_number = 1

    # Validieren + Binden
    bundle, binding, signature = validator.validate_and_bind(
        device_serial_hash=b"\x01" * 32,
        input_data=b"\x90\x40\x7F",
        hardware_signature=b"\x00" * 64,  # Dummy
        edit_event=event,
        public_key_bytes=public_bytes,
    )

    print(f"Bundle valid: {validator.proof_validator.is_human_verified(bundle)}")
    print(f"Binding created: {binding is not None}")
    print(f"Signature: {signature.hex()[:32]}...")

    # Versuche Replay
    if binding:
        replay_valid, replay_reason = validator.replay_detector.check_nonce(binding.nonce)
        print(f"Replay check: {replay_valid} ({replay_reason})")
