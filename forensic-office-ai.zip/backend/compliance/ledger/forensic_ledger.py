#!/usr/bin/env python3
"""
forensic_ledger.py
==================
The ForensicLedger with DAG structure for mashups/remixes.
Append-only, cryptographically linked, forensically auditable.
"""

import hashlib
import uuid
import time
from typing import List, Dict, Optional, Tuple, Set
from dataclasses import dataclass, field
from pathlib import Path
import json

from canonical_validator import CanonicalValidator, StrictProtobufParser
from ed25519_signer import Ed25519Signer


# PhysicalProof Integration (Anti-Spoofing)
try:
    from compliance.causality.physical_proof import (
        PhysicalProofValidator, PhysicalProofBundle, enrich_event_with_physical_proof
    )
    PHYSICAL_PROOF_AVAILABLE = True
except ImportError:
    PHYSICAL_PROOF_AVAILABLE = False

try:
    from forensic_provenance.v1 import (
        DAWEditEvent, ForensicLedger, EdgeType, EngagementState,
        BGHCompliance, SchoepfungshoeheEstimate, ContributionMatrix
    )
    PROTOBUF_AVAILABLE = True
except ImportError:
    PROTOBUF_AVAILABLE = False


@dataclass
class LedgerConfig:
    """Configuration for ForensicLedger."""
    storage_path: Path = Path("./ledger_data")
    max_blocks_in_memory: int = 10000
    auto_archive_after_blocks: int = 100000
    bgh_threshold_edits: int = 5
    bgh_threshold_duration_ms: int = 300_000


class ForensicLedgerManager:
    """
    Manages the ForensicLedger with DAG support.

    Features:
        - Append-only blocks
        - DAG edges for mashups/remixes
        - Merkle root computation
        - BGH compliance auto-calculation
        - Contribution matrix for collaborations
    """

    def __init__(self, config: LedgerConfig = None):
        self.config = config or LedgerConfig()
        self.config.storage_path.mkdir(parents=True, exist_ok=True)
        self.validator = CanonicalValidator()
        self.signer = Ed25519Signer()
        self.ledgers: Dict[str, ForensicLedger] = {}
        self._load_existing_ledgers()
        self.physical_proof_validator = PhysicalProofValidator() if PHYSICAL_PROOF_AVAILABLE else None


    def _load_existing_ledgers(self) -> None:
        """Load existing ledgers from storage."""
        for ledger_file in self.config.storage_path.glob("*.ledger"):
            ledger_id = ledger_file.stem
            ledger = ForensicLedger()
            with open(ledger_file, 'rb') as f:
                ledger.ParseFromString(f.read())
            self.ledgers[ledger_id] = ledger

    def create_ledger(self, asset_id: str, asset_type: str = "AUDIO") -> ForensicLedger:
        """Create a new ForensicLedger for an asset."""
        ledger_id = str(uuid.uuid4())
        ledger = ForensicLedger()
        ledger.schema_version = "3.0-forensic"
        ledger.ledger_id = ledger_id
        ledger.asset_id = asset_id
        ledger.asset_type = getattr(ForensicLedger.AssetType, asset_type, 1)
        ledger.state = ForensicLedger.LEDGER_STATE_ACTIVE

        # Create genesis block
        genesis = DAWEditEvent()
        genesis.event_id = str(uuid.uuid4())
        genesis.sequence_number = 0
        genesis.timestamp_unix_ns = time.time_ns()
        genesis.asset_id = asset_id
        genesis.session_id = str(uuid.uuid4())
        genesis.edge.type = EdgeType.EDGE_TYPE_IDENTICAL
        genesis.edge.arity = 1
        genesis.edge.logic = "genesis"
        genesis.engagement_state = EngagementState.ENGAGEMENT_STATE_IDLE
        genesis.bgh_relevant = False
        genesis.metadata_nonce = b'\x00' * 16

        ledger.genesis_block.CopyFrom(genesis)
        ledger.blocks.append(genesis)
        ledger.merkle_root = self._compute_merkle_root(ledger)

        self.ledgers[ledger_id] = ledger
        self._save_ledger(ledger)

        return ledger

    def append_block(self, ledger_id: str, event: DAWEditEvent) -> Tuple[bool, str]:
        """
        Append a new block to the ledger.

        Returns:
            (success, message_or_error)
        """
        if ledger_id not in self.ledgers:
            return False, f"Ledger {ledger_id} not found"

        ledger = self.ledgers[ledger_id]

        if ledger.state != ForensicLedger.LEDGER_STATE_ACTIVE:
            return False, f"Ledger is {ledger.state.name}, cannot append"

        # Validate event
        validation = self.validator.validate(event)
        if not validation.valid:
            return False, f"Validation failed: {validation.violations}"

        # Verify sequence
        expected_seq = len(ledger.blocks)
        if event.sequence_number != expected_seq:
            return False, f"Sequence mismatch: expected {expected_seq}, got {event.sequence_number}"

        # Verify parent hash
        last_block = ledger.blocks[-1]
        expected_parent = self.validator.compute_hash(last_block)
        if event.input_verification.parent_hash != expected_parent:
            return False, "Parent hash mismatch - chain broken"


        # === PHYSICAL PROOF VALIDATION + ANTI-REPLAY (Anti-Spoofing) ===
        if self.physical_proof_validator and event.HasField('hardware_input'):
            # Extrahiere Hardware-Signatur (aus TrustAnchor oder separat)
            hw_sig = event.trust.signature if event.HasField('trust') else b""

            # Validierung MIT Anti-Replay-Binding
            proof_bundle, binding, ar_signature = self.physical_proof_validator.validate_human_action_with_binding(
                device_serial_hash=event.hardware_input.device_serial_hash,
                input_data=event.hardware_input.SerializeToString(),
                hardware_signature=hw_sig,
                edit_event=event,  # Wichtig: Für Anti-Replay-Binding
                parameter_delta=event.parameter_delta if event.HasField('parameter_delta') else None,
            )

            # Erweitere Event mit PhysicalProof-Ergebnissen
            enrich_event_with_physical_proof(event, proof_bundle, self.physical_proof_validator)

            # Anti-Replay-Binding in TrustAnchor speichern
            if binding and ar_signature:
                event.trust.combined_hash = binding.combined_hash
                event.trust.proof_bundle_hash = binding.proof_bundle_hash
                event.trust.edit_event_hash = binding.edit_event_hash
                event.trust.anti_replay_nonce = binding.nonce
                event.trust.signature = ar_signature  # Überschreibt alte Signatur!
                event.trust.physical_proof_confidence = proof_bundle.overall_confidence
                event.trust.physical_proof_passed = self.physical_proof_validator.is_human_verified(proof_bundle)

            # Wenn nicht menschlich verifiziert, markiere als UNVERIFIED
            if not self.physical_proof_validator.is_human_verified(proof_bundle):
                event.causality.initiator.source_type = 5  # SOURCE_TYPE_EXTERNAL_DEVICE
                event.causality.executor.source_type = 5
                event.bgh_relevant = False

                # Logge Verdacht
                print(f"[WARN] Potential KI injection detected in block {event.sequence_number}")
                print(f"       Confidence: {proof_bundle.overall_confidence:.2f}")
                print(f"       Violations: {proof_bundle.violations}")
                if binding:
                    print(f"       Anti-Replay: Nonce {binding.nonce.hex()[:16]}... bound to event {event.event_id}")

        # Sign the block
        canonical = validation.canonical_blob
        signature = self.signer.sign(canonical)
        event.trust.CopyFrom(signature)

        # Append
        ledger.blocks.append(event)

        # Update DAG edges if synthesis
        if event.edge.type == EdgeType.EDGE_TYPE_SYNTHESIS and len(event.edge.parent_hashes) > 1:
            for parent_hash in event.edge.parent_hashes:
                parent_block = self._find_block_by_hash(ledger, parent_hash)
                if parent_block:
                    edge = ledger.dag_edges.add()
                    edge.from_event_id = parent_block.event_id
                    edge.to_event_id = event.event_id
                    edge.type = EdgeType.EDGE_TYPE_SYNTHESIS

        # Update Merkle root
        ledger.merkle_root = self._compute_merkle_root(ledger)

        # Update BGH compliance
        self._update_bgh_compliance(ledger)

        # Save
        self._save_ledger(ledger)

        return True, f"Block {event.sequence_number} appended"

    def _find_block_by_hash(self, ledger: ForensicLedger, hash_bytes: bytes) -> Optional[DAWEditEvent]:
        """Find a block by its content hash."""
        for block in ledger.blocks:
            if self.validator.compute_hash(block) == hash_bytes:
                return block
        return None

    def _compute_merkle_root(self, ledger: ForensicLedger) -> bytes:
        """Compute Merkle root of all blocks."""
        hashes = [self.validator.compute_hash(b) for b in ledger.blocks]
        if len(hashes) == 0:
            return b'\x00' * 32

        while len(hashes) > 1:
            new_level = []
            for i in range(0, len(hashes), 2):
                left = hashes[i]
                right = hashes[i + 1] if i + 1 < len(hashes) else left
                combined = hashlib.sha256(left + right).digest()
                new_level.append(combined)
            hashes = new_level

        return hashes[0]

    def _update_bgh_compliance(self, ledger: ForensicLedger) -> None:
        """Auto-calculate BGH compliance metrics."""
        human_initiated = 0
        human_executed = 0
        ai_suggested = 0
        automation_executed = 0
        total_duration = 0

        contributors: Dict[bytes, Dict] = {}

        for block in ledger.blocks:
            if block.engagement_state == EngagementState.ENGAGEMENT_STATE_ACTIVE:
                total_duration += block.edit_duration_ms

                if block.causality.initiator.source_type == 1:  # HUMAN
                    human_initiated += 1
                elif block.causality.initiator.source_type == 2:  # AI
                    ai_suggested += 1

                if block.causality.executor.source_type == 1:  # HUMAN
                    human_executed += 1
                    # Track contributor
                    actor_hash = block.causality.executor.id_hash
                    if actor_hash not in contributors:
                        contributors[actor_hash] = {"mutations": 0, "duration": 0}
                    contributors[actor_hash]["mutations"] += 1
                    contributors[actor_hash]["duration"] += block.edit_duration_ms
                elif block.causality.executor.source_type == 3:  # AUTOMATION
                    automation_executed += 1

        # Calculate threshold
        threshold_passed = human_executed >= self.config.bgh_threshold_edits or                           total_duration >= self.config.bgh_threshold_duration_ms

        # Estimate Schöpfungshöhe
        estimate = SchoepfungshoeheEstimate.UNLIKELY
        if human_executed >= 20 and total_duration >= 600_000:
            estimate = SchoepfungshoeheEstimate.CERTAIN
        elif human_executed >= 10 and total_duration >= 300_000:
            estimate = SchoepfungshoeheEstimate.LIKELY
        elif human_executed >= 5 or total_duration >= 300_000:
            estimate = SchoepfungshoeheEstimate.POSSIBLE

        # Build compliance
        compliance = BGHCompliance()
        compliance.human_initiated_mutations = human_initiated
        compliance.human_executed_mutations = human_executed
        compliance.ai_suggested_mutations = ai_suggested
        compliance.automation_executed_mutations = automation_executed
        compliance.total_edit_duration_ms = total_duration
        compliance.threshold_passed = threshold_passed
        compliance.schoepfungshoehe_estimate = estimate

        # Contribution matrix
        total_mutations = sum(c["mutations"] for c in contributors.values())
        for actor_hash, data in contributors.items():
            contrib = compliance.contributions.add()
            contrib.contributor_id_hash = actor_hash
            contrib.percentage = int((data["mutations"] / total_mutations) * 100) if total_mutations > 0 else 0
            contrib.mutations_count = data["mutations"]

        ledger.bgh_compliance.CopyFrom(compliance)

    def _save_ledger(self, ledger: ForensicLedger) -> None:
        """Persist ledger to disk."""
        path = self.config.storage_path / f"{ledger.ledger_id}.ledger"
        with open(path, 'wb') as f:
            f.write(ledger.SerializeToString())

    def verify_integrity(self, ledger_id: str) -> Tuple[bool, Dict]:
        """
        Verify full ledger integrity.

        Returns:
            (valid, report)
        """
        if ledger_id not in self.ledgers:
            return False, {"error": "Ledger not found"}

        ledger = self.ledgers[ledger_id]
        report = {
            "ledger_id": ledger_id,
            "blocks_count": len(ledger.blocks),
            "dag_edges_count": len(ledger.dag_edges),
            "checks": {}
        }

        # Check 1: Genesis block
        report["checks"]["genesis_valid"] = ledger.genesis_block.sequence_number == 0

        # Check 2: Chain continuity
        chain_valid = True
        for i in range(1, len(ledger.blocks)):
            prev_hash = self.validator.compute_hash(ledger.blocks[i-1])
            if ledger.blocks[i].input_verification.parent_hash != prev_hash:
                chain_valid = False
                break
        report["checks"]["chain_continuous"] = chain_valid

        # Check 3: Merkle root
        computed_root = self._compute_merkle_root(ledger)
        report["checks"]["merkle_root_valid"] = computed_root == ledger.merkle_root

        # Check 4: BGH compliance
        report["checks"]["bgh_computed"] = ledger.bgh_compliance.threshold_passed

        # Overall
        all_valid = all(report["checks"].values())
        report["overall_valid"] = all_valid

        return all_valid, report

    def get_ledger_summary(self, ledger_id: str) -> Dict:
        """Get human-readable summary of ledger."""
        if ledger_id not in self.ledgers:
            return {"error": "Not found"}

        ledger = self.ledgers[ledger_id]
        return {
            "ledger_id": ledger.ledger_id,
            "asset_id": ledger.asset_id,
            "state": ledger.state.name,
            "blocks": len(ledger.blocks),
            "dag_edges": len(ledger.dag_edges),
            "bgh": {
                "threshold_passed": ledger.bgh_compliance.threshold_passed,
                "estimate": ledger.bgh_compliance.schoepfungshoehe_estimate.name,
                "human_mutations": ledger.bgh_compliance.human_executed_mutations,
                "total_duration_sec": ledger.bgh_compliance.total_edit_duration_ms // 1000
            },
            "contributors": [
                {
                    "id_hash": c.contributor_id_hash.hex()[:16] + "...",
                    "percentage": c.percentage,
                    "mutations": c.mutations_count
                }
                for c in ledger.bgh_compliance.contributions
            ]
        }


if __name__ == "__main__":
    if not PROTOBUF_AVAILABLE:
        print("Generate protobuf first: protoc --python_out=. schema.proto")
        exit(1)

    manager = ForensicLedgerManager()

    # Create ledger
    ledger = manager.create_ledger("track-001", "AUDIO")
    print(f"Created ledger: {ledger.ledger_id}")

    # Verify empty ledger
    valid, report = manager.verify_integrity(ledger.ledger_id)
    print(f"Integrity: {valid}, {report}")

    # Get summary
    summary = manager.get_ledger_summary(ledger.ledger_id)
    print(f"Summary: {json.dumps(summary, indent=2, default=str)}")
