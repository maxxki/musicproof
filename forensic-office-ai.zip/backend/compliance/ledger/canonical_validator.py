#!/usr/bin/env python3
"""
canonical_validator.py
======================
Deterministic protobuf serialization validator.
Ensures bit-identical output across C++, Python, TypeScript implementations.
"""

import hashlib
import struct
from typing import List, Tuple, Optional, Union
from dataclasses import dataclass

# Generated from schema.proto
try:
    from forensic_provenance.v1 import DAWEditEvent, ForensicLedger, CanonicalValidationResponse
    PROTOBUF_AVAILABLE = True
except ImportError:
    PROTOBUF_AVAILABLE = False
    print("[WARN] Protobuf generated code not available. Run: protoc --python_out=.")


@dataclass(frozen=True)
class CanonicalRule:
    """Single canonical encoding rule with enforcement logic."""
    rule_id: int
    name: str
    description: str
    mandatory: bool
    check_fn: callable


class CanonicalValidator:
    """
    Validates and enforces canonical protobuf encoding rules.

    Rules derived from schema.proto comments:
    1. Fields sorted by field number (enforced by protoc)
    2. No unknown fields (strict parsing)
    3. Explicit defaults (never rely on proto3 zero-values for hashes/signatures)
    4. No maps (use repeated with explicit ordering)
    5. Fixed-point only (no floats in evidence-critical fields)
    6. Timestamps as uint64 nanoseconds
    7. Enums as int32
    8. Binary hashes as bytes (32 bytes raw)
    """

    REQUIRED_FIELDS = {
        'DAWEditEvent': [
            1, 2, 3, 4, 5, 6, 7, 8, 11, 12, 14, 15, 16, 18, 19, 21,
        ],
        'TrustAnchor': [1, 4, 5],
        'StateVerification': [1, 6],
    }

    MAX_CONFIG_SNAPSHOT_BYTES = 64 * 1024
    MAX_INTENT_DESCRIPTION_CHARS = 1024
    MAX_HASH_LENGTH = 32
    MAX_SIGNATURE_LENGTH = 64

    def __init__(self):
        self.violations: List[str] = []
        self.rules = self._build_rules()

    def _build_rules(self) -> List[CanonicalRule]:
        return [
            CanonicalRule(1, "FIELD_ORDER", "Fields sorted by field number", True, self._check_field_order),
            CanonicalRule(2, "NO_UNKNOWN_FIELDS", "No unknown fields", True, self._check_unknown_fields),
            CanonicalRule(3, "EXPLICIT_DEFAULTS", "Required fields explicitly set", True, self._check_explicit_defaults),
            CanonicalRule(4, "NO_MAPS", "No map types", True, self._check_no_maps),
            CanonicalRule(5, "FIXED_POINT_ONLY", "No floats in evidence fields", True, self._check_fixed_point),
            CanonicalRule(6, "TIMESTAMP_FORMAT", "Timestamps as uint64 ns", True, self._check_timestamp_format),
            CanonicalRule(7, "ENUM_ENCODING", "Enums as int32", True, self._check_enum_encoding),
            CanonicalRule(8, "HASH_FORMAT", "Binary hashes 32 bytes", True, self._check_hash_format),
            CanonicalRule(9, "SIGNATURE_FORMAT", "Ed25519 signatures 64 bytes", True, self._check_signature_format),
            CanonicalRule(10, "CANONICAL_MARKER", "canonical_compliance_marker empty", True, self._check_canonical_marker),
        ]

    def validate(self, event: 'DAWEditEvent') -> 'CanonicalValidationResponse':
        self.violations = []
        for rule in self.rules:
            try:
                rule.check_fn(event)
            except Exception as e:
                self.violations.append(f"Rule {rule.rule_id} ({rule.name}): {str(e)}")

        canonical_blob = self._serialize_canonical(event)
        computed_hash = hashlib.sha256(canonical_blob).digest()

        return CanonicalValidationResponse(
            valid=len(self.violations) == 0,
            computed_hash=computed_hash,
            violations=self.violations,
            canonical_blob=canonical_blob
        )

    def _check_field_order(self, event: 'DAWEditEvent') -> None:
        serialized = event.SerializeToString()
        reparsed = DAWEditEvent()
        reparsed.ParseFromString(serialized)
        canonical = reparsed.SerializeToString()
        if serialized != canonical:
            raise ValueError(f"Field order violation")

    def _check_unknown_fields(self, event: 'DAWEditEvent') -> None:
        if hasattr(event, 'UnknownFields') and event.UnknownFields():
            raise ValueError(f"Unknown fields: {event.UnknownFields()}")

    def _check_explicit_defaults(self, event: 'DAWEditEvent') -> None:
        msg_type = event.DESCRIPTOR.full_name.split('.')[-1]
        required = self.REQUIRED_FIELDS.get(msg_type, [])
        for field_num in required:
            field = event.DESCRIPTOR.fields_by_number[field_num]
            if not event.HasField(field.name):
                value = getattr(event, field.name)
                if self._is_default_value(field, value):
                    raise ValueError(f"Required field {field.name} is default")

    def _is_default_value(self, field, value) -> bool:
        if field.type == field.TYPE_MESSAGE:
            return all(getattr(value, f.name) == f.default_value for f in value.DESCRIPTOR.fields)
        elif field.type == field.TYPE_BYTES:
            return len(value) == 0
        elif field.type == field.TYPE_STRING:
            return len(value) == 0
        elif field.type in (field.TYPE_UINT64, field.TYPE_UINT32):
            return value == 0
        elif field.type == field.TYPE_BOOL:
            return value == False
        return False

    def _check_no_maps(self, event: 'DAWEditEvent') -> None:
        for field in event.DESCRIPTOR.fields:
            if field.label == field.LABEL_REPEATED and field.message_type:
                if field.message_type.GetOptions().map_entry:
                    raise ValueError(f"Map field: {field.name}")

    def _check_fixed_point(self, event: 'DAWEditEvent') -> None:
        if event.HasField('parameter_delta'):
            for val in [event.parameter_delta.old_value, event.parameter_delta.new_value]:
                if hasattr(val, 'float_value'):
                    raise ValueError("Float in FixedPointValue")

    def _check_timestamp_format(self, event: 'DAWEditEvent') -> None:
        if event.timestamp_unix_ns == 0:
            raise ValueError("timestamp_unix_ns is 0")
        min_ns = 1577836800_000_000_000
        max_ns = 1893456000_000_000_000
        if not (min_ns <= event.timestamp_unix_ns <= max_ns):
            raise ValueError(f"timestamp out of range: {event.timestamp_unix_ns}")

    def _check_enum_encoding(self, event: 'DAWEditEvent') -> None:
        if event.engagement_state not in range(7):
            raise ValueError(f"Invalid engagement_state: {event.engagement_state}")
        if event.HasField('edge') and event.edge.type not in range(5):
            raise ValueError(f"Invalid edge.type: {event.edge.type}")

    def _check_hash_format(self, event: 'DAWEditEvent') -> None:
        hash_fields = [
            ('input_content_hash', event.input_content_hash),
            ('output_content_hash', event.output_content_hash),
        ]
        if event.HasField('input_verification'):
            hash_fields.append(('input_verification.parent_hash', event.input_verification.parent_hash))
        if event.HasField('output_verification'):
            hash_fields.append(('output_verification.parent_hash', event.output_verification.parent_hash))
        for name, value in hash_fields:
            if value is not None and len(value) != self.MAX_HASH_LENGTH:
                raise ValueError(f"Hash {name} length {len(value)} != {self.MAX_HASH_LENGTH}")

    def _check_signature_format(self, event: 'DAWEditEvent') -> None:
        if event.HasField('trust') and len(event.trust.signature) > 0:
            if len(event.trust.signature) != self.MAX_SIGNATURE_LENGTH:
                raise ValueError(f"Signature length {len(event.trust.signature)} != {self.MAX_SIGNATURE_LENGTH}")

    def _check_canonical_marker(self, event: 'DAWEditEvent') -> None:
        if len(event.canonical_compliance_marker) != 0:
            raise ValueError("canonical_compliance_marker must be empty")

    def _serialize_canonical(self, event: 'DAWEditEvent') -> bytes:
        event_copy = DAWEditEvent()
        event_copy.CopyFrom(event)
        if event_copy.HasField('parameter_delta'):
            if event_copy.parameter_delta.HasField('old_value'):
                event_copy.parameter_delta.old_value.display_string = ""
            if event_copy.parameter_delta.HasField('new_value'):
                event_copy.parameter_delta.new_value.display_string = ""
        if event_copy.HasField('environment'):
            event_copy.environment.config_snapshot_json = ""
        return event_copy.SerializeToString()

    def compute_hash(self, event: 'DAWEditEvent') -> bytes:
        return hashlib.sha256(self._serialize_canonical(event)).digest()


class StrictProtobufParser:
    def parse(self, blob: bytes, message_type: type) -> 'DAWEditEvent':
        msg = message_type()
        msg.ParseFromString(blob)
        if hasattr(msg, 'UnknownFields') and msg.UnknownFields():
            raise ValueError(f"Unknown fields: {msg.UnknownFields()}")
        return msg


if __name__ == "__main__":
    if not PROTOBUF_AVAILABLE:
        print("Please generate protobuf code first: protoc --python_out=. schema.proto")
        exit(1)
    from forensic_provenance.v1 import DAWEditEvent, EdgeDefinition, EdgeType
    event = DAWEditEvent()
    event.event_id = "550e8400-e29b-41d4-a716-446655440000"
    event.sequence_number = 1
    event.timestamp_unix_ns = 1749134589123456789
    event.asset_id = "660e8400-e29b-41d4-a716-446655440001"
    event.session_id = "770e8400-e29b-41d4-a716-446655440002"
    event.edge.type = EdgeType.EDGE_TYPE_MUTATION
    event.edge.arity = 1
    event.edge.logic = "param_eq"
    event.edge.parent_hashes.append(b'\x00' * 32)
    event.input_verification.parent_hash = b'\x00' * 32
    event.input_verification.verification_time_unix_ns = 1749134589000000000
    event.causality.initiator.id_hash = b'\x01' * 32
    event.causality.initiator.source_type = 1
    event.causality.initiator.action_origin = 3
    event.causality.executor.CopyFrom(event.causality.initiator)
    event.environment.software.name = "ForensicOffice AI"
    event.environment.software.version = "1.0.0"
    event.environment.software.binary_hash = b'\x02' * 32
    event.engagement_state = 2
    event.output_verification.parent_hash = b'\x03' * 32
    event.output_verification.verification_time_unix_ns = 1749134589100000000
    event.input_content_hash = b'\x04' * 32
    event.output_content_hash = b'\x05' * 32
    event.trust.signature = b'\x06' * 64
    event.trust.local_timestamp_unix_ns = 1749134589123456789
    event.bgh_relevant = True
    event.metadata_nonce = b'\x07' * 16
    validator = CanonicalValidator()
    result = validator.validate(event)
    print(f"Valid: {result.valid}")
    print(f"Hash: {result.computed_hash.hex()}")
    print(f"Violations: {result.violations}")
