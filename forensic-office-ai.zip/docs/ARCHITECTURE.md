# ARCHITECTURE.md

## Die 4 operativen Edge-Typen

| Typ | Mathematische Definition | Beispiel |
|-----|-------------------------|----------|
| IDENTICAL | H(B_i) = H(P_1) ∧ arity = 1 | Backup, Export |
| MUTATION | H(B_i) ≠ H(P_1) ∧ arity = 1 | EQ, Gain, Edit |
| SYNTHESIS | arity = n > 1 | Mixing, Mashup |
| SEGMENTATION | B_i ⊂ P_1 ∧ arity = 1 | Slicing, Crop |

## Die 7 Schritte der Kausalkette

1. **Hash-Verifikation** → parent_hash == expected?
2. **Initiator-Identifikation** → Wer hatte die Idee?
3. **Entscheidungs-Validierung** → confirmation_required?
4. **Executor-Identifikation** → Wer führte aus?
5. **Hardware-Input** → MIDI CC#12, Knob_4, etc.
6. **Parameter-Delta** → 8230.14 → 6170.22 Hz
7. **Output-Verifikation** → Hash + Signatur + TSA

## Trust-Level-Hierarchie

| Level | Speicher | Verwendung |
|-------|----------|------------|
| 1 (Software) | ~/.forensic_provenance/keys/ | Consumer, Development |
| 2 (TPM) | TPM/Secure Enclave | Pro-Studios, Enterprise |
| 3 (HSM) | PKCS#11 Token | Höchste Sicherheit |

## Canonical Encoding Rules

1. Felder nach Feld-ID sortiert
2. Keine unbekannten Felder (strict parsing)
3. Explizite Defaults (keine proto3-Zero-Values)
4. Keine Maps (repeated mit Sortierung)
5. Fixed-Point nur (keine Floats in Beweis-Feldern)
6. Timestamps als uint64 Nanosekunden
7. Enums als int32
8. Binary Hashes als raw bytes (32 Bytes)
9. Ed25519 Signaturen als raw bytes (64 Bytes)
10. _canonical_compliance_marker muss leer sein
