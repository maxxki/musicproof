# COMPLIANCE.md

## BGH-Konformität (Urheberrecht)

### Automatische Schöpfungshöhe-Prüfung

Das System implementiert die Kriterien des BGH-Urteils vom 11.06.2024 (Az. I ZR 192/23):

| Kriterium | Schwellenwert | Messung |
|-----------|--------------|---------|
| Menschliche Mutationen | ≥ 5 | EdgeType.MUTATION + source_type=HUMAN |
| Edit-Dauer | ≥ 300 Sekunden | engagement_duration_ms |
| Hardware-Verifizierung | ≥ 10 Events | hardware_signature vorhanden |
| Manuelle Verifizierung | ≥ 5 | confirmation_required=true |

### Schöpfungshöhe-Estimation

```
UNLIKELY  → < 5 Mutations UND < 300s
POSSIBLE  → ≥ 5 Mutations ODER ≥ 300s
LIKELY    → ≥ 10 Mutations UND ≥ 300s + manual_verified ≥ 5
CERTAIN   → ≥ 20 Mutations UND ≥ 600s + hardware_verified ≥ 10
```

## DSGVO-Konformität

### Art. 25 (Privacy by Design)
- Lokale Verarbeitung (kein Cloud-Call)
- Pseudonymisierung aller Actor-IDs (SHA-256)
- PII-Hashing in Parameter-Delta
- Differential Privacy (ε-konfigurierbar)

### Art. 32 (Sicherheit)
- Ed25519-Signaturen für alle Events
- HSM-Quorum (3-of-5) für kritische Operationen
- WORM-Storage für Audit-Logs

## EU AI Act (Annex IV)

### High-Risk System Documentation
- Automatische Risko-Klassifizierung pro Asset-Type
- Technische Dokumentation (auto-generiert)
- Konformitäts-Bewertung (Self-Assessment)
- Post-Market Monitoring (Ledger-basiert)

## 21 CFR Part 11 (GMP)

### ALCOA+ Prinzipien
| Prinzip | Implementierung |
|---------|----------------|
| Attributable | ActorIdentity (Initiator + Executor) |
| Legible | FixedPointValue + display_string |
| Contemporaneous | Unix-Nanosekunden + Dual-TSA |
| Original | Genesis-Block + Hash-Chain |
| Accurate | Canonical Validator + Protobuf |
| + Complete | DAG-Struktur für alle Transformationen |
| + Consistent | Deterministische Serialisierung |
| + Enduring | WORM-Storage + Blockchain-Anker |
| + Available | REST API + Export-Funktionen |

## eIDAS-Konformität

### Elektronische Signaturen
- **Advanced**: Ed25519 (Software-Key)
- **Qualified**: ECDSA-P256 + HSM (PKCS#11)
- **PAdES**: PDF/A-3b mit eingebetteter Signatur

### Zeitstempel
- **RFC 3161**: Dual-TSA (Telekom + SwissSign)
- **Blockchain**: Bitcoin/Ethereum Anchor (optional)
