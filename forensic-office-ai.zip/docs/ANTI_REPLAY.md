# ANTI_REPLAY.md

## Anti-Replay Signatur-Wrapper

### Das Problem

Ohne Anti-Replay-Binding kann ein Angreifer:
1. Ein legitimes Event A mit gültigem PhysicalProof aufzeichnen
2. Das Proof-Bundle von A kopieren
3. Ein gefälschtes Event B erstellen
4. Das Proof-Bundle von A auf Event B anwenden
5. Die Verifizierung schlägt fehl, da `H_edit_event` unterschiedlich ist

### Die Lösung

**Kryptographische Bindung:** Die Signatur wird über einen kombinierten Hash gebildet:

```
H_combined = SHA256( H_proof_bundle || H_edit_event || nonce )
```

Dadurch ist das Proof-Bundle an ein **spezifisches Edit-Event** gebunden.

### Komponenten

| Feld | Bedeutung |
|------|-----------|
| `combined_hash` | SHA256( proof_hash + event_hash + nonce ) |
| `proof_bundle_hash` | SHA256( serialisiertes PhysicalProofBundle ) |
| `edit_event_hash` | SHA256( canonical Edit-Event ) |
| `anti_replay_nonce` | 32 Bytes frisches Nonce pro Signatur |
| `signature` | Ed25519-Signatur über `combined_hash` |

### Verifizierungsablauf

```python
def verify(event, trust_anchor, proof_bundle, public_key):
    # 1. Rekonstruiere Proof-Bundle-Hash
    current_proof_hash = hash_proof_bundle(proof_bundle)
    assert current_proof_hash == trust_anchor.proof_bundle_hash

    # 2. Rekonstruiere Edit-Event-Hash
    current_event_hash = canonical_hash(event)
    assert current_event_hash == trust_anchor.edit_event_hash

    # 3. Rekonstruiere kombinierten Hash
    reconstructed = SHA256(
        trust_anchor.proof_bundle_hash + 
        trust_anchor.edit_event_hash + 
        trust_anchor.anti_replay_nonce
    )
    assert reconstructed == trust_anchor.combined_hash

    # 4. Verifiziere Signatur
    return ed25519_verify(public_key, trust_anchor.signature, trust_anchor.combined_hash)
```

### Nonce-Replay-Schutz

Zusätzlich zum Hash-Binding wird ein **Nonce-Tracking** verwendet:

- Jedes Proof-Bundle enthält ein frisches 32-Byte Nonce
- Nonces werden in einem Ring-Buffer gespeichert (5 Minuten TTL)
- Wiederholte Nonces werden als Replay-Angriff erkannt

### Integration im TrustAnchor

```protobuf
message TrustAnchor {
    // Anti-Replay Felder
    bytes combined_hash = 2;
    bytes proof_bundle_hash = 3;
    bytes edit_event_hash = 4;
    bytes anti_replay_nonce = 5;

    // PhysicalProof Metadaten
    float physical_proof_confidence = 12;
    bool physical_proof_passed = 13;

    // Legacy Felder
    bytes signature = 1;
    // ...
}
```

### Angriffsszenarien

| Angriff | Erkennung |
|---------|-----------|
| Proof-Bundle von Event A auf Event B | `edit_event_hash` mismatch |
| Altes Proof-Bundle wiederverwenden | `nonce` bereits in `ReplayAttackDetector` |
| Nonce wiederverwenden | `ReplayAttackDetector` erkennt Duplikat |
| Hash-Kollision | SHA256-Kollisionsresistenz |
| Signatur-Fälschung | Ed25519-Sicherheit |
