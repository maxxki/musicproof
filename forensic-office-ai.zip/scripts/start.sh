#!/bin/bash
set -e

echo "🚀 Starting ForensicOffice AI..."

# Check dependencies
command -v protoc >/dev/null 2>&1 || { echo "protoc required but not installed. Aborting." >&2; exit 1; }

# Generate protobuf if needed
if [ ! -f "backend/forensic_provenance/v1/schema_pb2.py" ]; then
    echo "📦 Generating Protobuf..."
    mkdir -p backend/forensic_provenance/v1
    protoc --python_out=backend shared/types/schema.proto
fi

# Check models
if [ ! -d "llama.cpp/models" ] || [ -z "$(ls -A llama.cpp/models/*.gguf 2>/dev/null)" ]; then
    echo "⚠️  No GGUF models found in llama.cpp/models/"
    echo "   Please add your models:"
    echo "   - deepseek-coder-1.3b-instruct.Q4_K_M.gguf"
    echo "   - granite-3.0-2b-instruct-Q4_K_M.gguf"
    echo "   - qwen2.5-coder-3b-instruct-iq4_xs.gguf"
    echo "   - DeepSeek-R1-Qwen-1.5B.gguf"
    echo "   - Qwen2-1.5B-Instruct-Q4_K_M.gguf"
fi

# Start LLM Server (default model)
DEFAULT_MODEL="llama.cpp/models/granite-3.0-2b-instruct-Q4_K_M.gguf"
if [ -f "$DEFAULT_MODEL" ]; then
    echo "🧠 Starting LLM Server with granite-3.0-2b..."
    ./llama.cpp/llama-server -m "$DEFAULT_MODEL" --port 8080 -c 4096 --host 127.0.0.1 &
    LLM_PID=$!
else
    echo "⚠️  Default model not found, skipping LLM server"
fi

# Start Backend
echo "🔧 Starting FastAPI Backend..."
cd backend
python -m uvicorn main:app --host 0.0.0.0 --port 8000 --reload &
BACKEND_PID=$!
cd ..

# Start Frontend
echo "🎨 Starting Frontend..."
cd frontend
npm install 2>/dev/null || true
npm run dev &
FRONTEND_PID=$!
cd ..

echo ""
echo "✅ ForensicOffice AI is running:"
echo "   🌐 Frontend:    http://localhost:3000"
echo "   🔌 Backend API: http://localhost:8000"
echo "   📚 API Docs:    http://localhost:8000/docs"
echo "   🧠 LLM Server:  http://localhost:8080"
echo ""
echo "Press Ctrl+C to stop all services"

# Cleanup on exit
cleanup() {
    echo ""
    echo "🛑 Shutting down..."
    kill $LLM_PID $BACKEND_PID $FRONTEND_PID 2>/dev/null || true
    exit 0
}
trap cleanup INT TERM

wait
