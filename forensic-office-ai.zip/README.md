# ForensicOffice AI

**On-Premise Office Suite mit lokaler KI + Forensischer Compliance Engine**

## 🎯 Vision

Ein webbasiertes, On-Premise Office-System mit lokaler KI-Inference (llama.cpp) und integrierter forensischer Compliance-Engine. Jede Benutzeraktion wird kryptographisch beweiskräftig protokolliert — für Kanzleien, Kreative und GMP-Umgebungen.

## 🏗️ Architektur

```
┌─────────────────────────────────────────────────────────────┐
│                    FRONTEND (Vite + React + TS)              │
│  ┌──────────┐  ┌──────────┐  ┌──────────┐  ┌──────────────┐  │
│  │  Editor  │  │  Chat    │  │  Files   │  │  Compliance  │  │
│  │ (TipTap) │  │ (Stream) │  │ (Browser)│  │ (Dashboard) │  │
│  └──────────┘  └──────────┘  └──────────┘  └──────────────┘  │
└─────────────────────────┬───────────────────────────────────┘
                          │ REST API / WebSocket
┌─────────────────────────┴───────────────────────────────────┐
│                    BACKEND (FastAPI + Python)               │
│  ┌──────────┐  ┌──────────┐  ┌──────────┐  ┌──────────────┐  │
│  │  Auth    │  │  LLM     │  │  Forensic│  │  Evidence    │  │
│  │ (Local)  │  │ Router   │  │ Ledger   │  │ Generator   │  │
│  └──────────┘  └──────────┘  └──────────┘  └──────────────┘  │
│                    llama.cpp Server (localhost:8080)            │
└─────────────────────────────────────────────────────────────┘
```

## 🔑 Kern-Features

### Forensische Compliance Engine
- **ProofBlock**: Jede Aktion = kryptographisch signierter Block (Ed25519)
- **DAG-Ledger**: Gerichtet-azyklischer Graph für Mashups/Remixes
- **7-Schritte Kausalkette**: Initiator → Executor → Hardware → Parameter → Verifikation
- **BGH-Automatik**: Auto-Berechnung der Schöpfungshöhe nach BGH-Urteil 2024
- **Dual-TSA**: Unabhängige Zeitstempel (Telekom + SwissSign)
- **Evidence-Artefakte**: PDF/A-3b, C2PA, JSON-LD, CBOR

### Lokale KI-Inference
- **llama.cpp**: Keine Cloud-Calls, 100% On-Premise
- **Model-Routing**: Code/General/Reasoning/Chat/Coder
- **Schwache Hardware**: Optimiert für 1.5B-3B Modelle (Q4-Quantisierung)

### Modulare Architektur
- **Plugin-System**: Jedes Feature ist ein austauschbares Modul
- **Hot-Swap**: Modelle zur Laufzeit wechseln
- **Zero-Trust**: Air-Gap möglich, keine externe Abhängigkeiten

## 📁 Repository-Struktur

```
forensic-office-ai/
├── shared/types/schema.proto      # Single Point of Truth (Protobuf)
├── backend/
│   ├── main.py                    # FastAPI Entry Point
│   ├── compliance/
│   │   ├── ledger/
│   │   │   ├── forensic_ledger.py      # DAG-Ledger Manager
│   │   │   └── canonical_validator.py  # Deterministische Serialisierung
│   │   ├── causality/
│   │   │   ├── engagement_state_machine.py  # BGH-Zustände
│   │   │   └── detector.py              # Initiator/Executor-Erkennung
│   │   ├── crypto/
│   │   │   └── ed25519_signer.py        # Ed25519 + Trust-Level
│   │   └── evidence/
│   │       └── generator.py            # PDF/A-3b, C2PA Export
│   └── llm/
│       └── router.py              # Model-Routing
├── frontend/
│   ├── src/
│   │   ├── components/compliance/ # Forensic Dashboard
│   │   ├── hooks/                 # React Hooks
│   │   ├── services/              # API Clients
│   │   └── stores/                # Zustand State
│   └── package.json
├── llama.cpp/models/              # GGUF Modelle (nicht im Git)
└── docs/
    ├── ARCHITECTURE.md
    ├── COMPLIANCE.md
    └── FORENSIC_SCHEMA.md
```

## 🚀 Quick Start

### Voraussetzungen
- Python 3.10+
- Node.js 18+
- llama.cpp (gebaut von Source)
- Protobuf Compiler (`protoc`)

### Installation

```bash
# 1. Repository klonen
cd forensic-office-ai

# 2. Protobuf generieren
protoc --python_out=backend shared/types/schema.proto

# 3. Backend dependencies
pip install fastapi uvicorn cryptography protobuf httpx

# 4. Frontend dependencies
cd frontend
npm install

# 5. Modelle platzieren
mkdir -p llama.cpp/models
cp ~/models/*.gguf llama.cpp/models/

# 6. Starten
./scripts/start.sh
```

### Start-Skript

```bash
#!/bin/bash
# scripts/start.sh

# Start llama.cpp server
./llama.cpp/llama-server -m ./llama.cpp/models/granite-3.0-2b-instruct-Q4_K_M.gguf --port 8080 &

# Start FastAPI backend
cd backend
uvicorn main:app --host 0.0.0.0 --port 8000 --reload &

# Start Frontend
cd frontend
npm run dev &

echo "ForensicOffice AI läuft:"
echo "  Frontend: http://localhost:3000"
echo "  Backend API: http://localhost:8000"
echo "  LLM Server: http://localhost:8080"
```

## 🔒 Sicherheit

| Aspekt | Maßnahme |
|--------|----------|
| Lokale Ausführung | llama.cpp bindet an 127.0.0.1 |
| Kryptographie | Ed25519 + ECDSA-P256 + SHA-256 |
| Trust-Level | Software → TPM → HSM (escalierbar) |
| Zeitstempel | Dual-TSA (Telekom + SwissSign) |
| Archivierung | WORM-Storage + Blockchain-Anker |
| Auth | Lokale SQLite, keine Cloud-Auth |

## 📜 Compliance-Standards

| Standard | Unterstützung |
|----------|--------------|
| BGH Urteil 2024 (Az. I ZR 192/23) | ✅ Schöpfungshöhe-Automatik |
| DSGVO Art. 25 + 32 | ✅ Privacy-by-Design |
| EU AI Act (Annex IV) | ✅ High-Risk Dokumentation |
| 21 CFR Part 11 | ✅ ALCOA+ konform |
| eIDAS | ✅ PAdES + HSM-Signaturen |
| C2PA | ✅ Content Provenance |



## 🛡️ Anti-Spoofing / Anti-KI-Injection

Das System erkennt KI-generierte Eingaben durch **4 Verteidigungsebenen**:

### Ebene 1: Hardware-Attestation (TPM/HSM)
- **Secure Element** (ATECC608A) im MIDI-Controller signiert jede Eingabe
- **TPM Remote Attestation**: OS beweist, dass es nicht kompromittiert ist
- **USB-Topologie-Scan**: Erkennt virtuelle Treiber (loopMIDI, etc.)
- **Challenge-Response**: Anti-Replay-Schutz

### Ebene 2: Sensor-Fusion
- Korreliert MIDI-Daten mit OS-Interrupts, Hardware-IRQs, USB-URBs
- Erkennt "orphaned" MIDI-Events (kein Hardware-Korrelat)
- USB-Fragmentierungs-Analyse (echte USB = Fragmente, Injiziert = vollständig)

### Ebene 3: Noise-Metriken (Biologische Varianz)
| Metrik | Menschlich | KI-Generiert |
|--------|-----------|-------------|
| Jitter σ | 20-80ms | <10ms oder >100ms |
| Tremor-Frequenz | 8-12 Hz | Keiner oder falsch |
| Lyapunov-Exponent | >0.1 (chaotisch) | ≈0 (nicht chaotisch) |
| Hurst-Exponent | 0.3-0.7 | <0.2 oder >0.8 |
| Entropie | 2.0-4.0 bits | Zu niedrig oder zu hoch |
| Fraktale Dimension | 1.2-1.5 | 1.0 (glatt) oder 2.0 (rau) |

### Ebene 4: Backtracking-Erkennung
- Menschen: 20-40% der Aktionen sind Rückschritte (Exploration)
- KI: Monoton oder perfekt optimiert (Gradient Descent)
- Erkennt "kreative Fingerabdrücke" vs. "optimale Trajektorien"

### Integration im Ledger
```python
# Jeder Block wird vor dem Append geprüft
proof_bundle = physical_proof_validator.validate_human_action(
    device_serial_hash=event.hardware_input.device_serial_hash,
    input_data=event.hardware_input.SerializeToString(),
    hardware_signature=event.trust.signature,
)

if not proof_bundle.is_human_verified():
    event.causality.initiator.source_type = UNVERIFIED
    event.bgh_relevant = False
    # Logge Verdacht auf KI-Injektion
```

## 🛠️ Tech Stack

| Layer | Technologie |
|-------|------------|
| Frontend | Vite + React + TypeScript + Zustand |
| Backend | FastAPI + Python 3.10 |
| KI-Inference | llama.cpp (GGUF) |
| Serialisierung | Protobuf (Canonical Encoding) |
| Kryptographie | Ed25519 + cryptography (Python) |
| Visualisierung | D3.js |
| Editor | TipTap / ProseMirror |

## 📄 Lizenz

MIT + Compliance-Addendum: Die forensischen Komponenten (Ledger, Evidence, BGH-Validator) sind unter einer speziellen Lizenz, die Modifikationen an der Beweiskette verbietet.

---

**Entwickelt in Regensburg** 🇩🇪 | **Für Kanzleien, Kreative und GMP-Umgebungen**
