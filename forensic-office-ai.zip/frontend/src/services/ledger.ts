import axios from 'axios'

const API_BASE = '/api'

export const LedgerAPI = {
  async list() {
    const { data } = await axios.get(`${API_BASE}/ledger/list`)
    return data
  },

  async create(assetId: string, assetType: string) {
    const { data } = await axios.post(`${API_BASE}/ledger/create`, { assetId, assetType })
    return data
  },

  async get(ledgerId: string) {
    const { data } = await axios.get(`${API_BASE}/ledger/${ledgerId}/summary`)
    return data
  },

  async verify(ledgerId: string) {
    const { data } = await axios.get(`${API_BASE}/ledger/${ledgerId}/verify`)
    return data
  }
}
