import axios from 'axios'

const API_BASE = '/api'

export const ComplianceAPI = {
  async getStatus(ledgerId: string) {
    const { data } = await axios.get(`${API_BASE}/compliance/status/${ledgerId}`)
    return data
  },

  async exportEvidence(ledgerId: string, format: string) {
    const { data } = await axios.post(
      `${API_BASE}/compliance/export`,
      { ledgerId, format },
      { responseType: 'blob' }
    )
    return data
  },

  async verifyLedger(ledgerId: string) {
    const { data } = await axios.get(`${API_BASE}/ledger/${ledgerId}/verify`)
    return data
  }
}
