import React, { useState } from 'react'
import { ComplianceAPI } from '../../services/compliance'

type ExportFormat = 'PDFA3B' | 'C2PA' | 'JSON_LD' | 'CBOR'

const EvidenceExporter: React.FC<{ ledgerId: string }> = ({ ledgerId }) => {
  const [format, setFormat] = useState<ExportFormat>('PDFA3B')
  const [exporting, setExporting] = useState(false)
  const [result, setResult] = useState<string | null>(null)

  const handleExport = async () => {
    if (!ledgerId) return
    setExporting(true)
    try {
      const response = await ComplianceAPI.exportEvidence(ledgerId, format)
      setResult(`Exported: ${response.artifactId} (${format})`)
      // Trigger download
      const blob = new Blob([response.data], { type: 'application/octet-stream' })
      const url = URL.createObjectURL(blob)
      const a = document.createElement('a')
      a.href = url
      a.download = `evidence_${ledgerId.slice(0, 8)}.${format.toLowerCase()}`
      a.click()
    } catch (e) {
      setResult(`Error: ${e}`)
    } finally {
      setExporting(false)
    }
  }

  return (
    <div className="evidence-exporter">
      <div className="format-selector">
        {(['PDFA3B', 'C2PA', 'JSON_LD', 'CBOR'] as ExportFormat[]).map(f => (
          <button
            key={f}
            className={format === f ? 'active' : ''}
            onClick={() => setFormat(f)}
          >
            {f}
          </button>
        ))}
      </div>
      <button 
        onClick={handleExport} 
        disabled={!ledgerId || exporting}
        className="export-btn"
      >
        {exporting ? '⏳ Exporting...' : '📥 Export Evidence'}
      </button>
      {result && <div className="export-result">{result}</div>}
    </div>
  )
}

export default EvidenceExporter
