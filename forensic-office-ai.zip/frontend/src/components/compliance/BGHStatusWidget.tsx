import React, { useEffect, useState } from 'react'
import { ComplianceAPI } from '../../services/compliance'

interface BGHData {
  thresholdPassed: boolean
  estimate: string
  humanMutations: number
  totalDurationSec: number
  progress: number
}

const BGHStatusWidget: React.FC<{ ledgerId: string }> = ({ ledgerId }) => {
  const [data, setData] = useState<BGHData | null>(null)

  useEffect(() => {
    if (!ledgerId) return
    ComplianceAPI.getStatus(ledgerId).then(status => {
      const progress = Math.min(
        (status.humanMutations / 5) * 100,
        (status.totalDurationSec / 300) * 100
      )
      setData({
        thresholdPassed: status.bghConformity !== 'UNLIKELY' && status.bghConformity !== 'POSSIBLE',
        estimate: status.bghConformity,
        humanMutations: status.humanMutations,
        totalDurationSec: status.totalDurationSec,
        progress: Math.min(progress, 100)
      })
    })
  }, [ledgerId])

  if (!data) return <div>Loading...</div>

  return (
    <div className="bgh-widget">
      <div className="progress-bar">
        <div 
          className="progress-fill" 
          style={{ width: `${data.progress}%`, background: data.thresholdPassed ? '#22c55e' : '#eab308' }}
        />
      </div>
      <div className="bgh-stats">
        <div>Mutations: {data.humanMutations} / 5</div>
        <div>Duration: {Math.floor(data.totalDurationSec / 60)}m {data.totalDurationSec % 60}s / 5m</div>
        <div>Estimate: <strong>{data.estimate}</strong></div>
      </div>
      {data.thresholdPassed ? (
        <div className="bgh-success">✅ BGH Threshold Passed</div>
      ) : (
        <div className="bgh-warning">⚠️ Need more human edits</div>
      )}
    </div>
  )
}

export default BGHStatusWidget
