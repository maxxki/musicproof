import React, { useEffect, useRef } from 'react'
import * as d3 from 'd3'
import { useLedgerStore } from '../../stores/ledgerStore'

const LedgerVisualizer: React.FC<{ ledgerId: string }> = ({ ledgerId }) => {
  const svgRef = useRef<SVGSVGElement>(null)
  const { getLedger } = useLedgerStore()

  useEffect(() => {
    if (!ledgerId || !svgRef.current) return

    const ledger = getLedger(ledgerId)
    if (!ledger) return

    const svg = d3.select(svgRef.current)
    svg.selectAll("*").remove()

    const width = 600
    const height = 300
    const nodeRadius = 20

    // Create nodes from blocks
    const nodes = ledger.blocks.map((block, i) => ({
      id: block.eventId,
      x: (i / Math.max(ledger.blocks.length - 1, 1)) * (width - 100) + 50,
      y: height / 2,
      type: block.edge.type,
      sequence: block.sequenceNumber,
      bghRelevant: block.bghRelevant
    }))

    // Create links from DAG edges
    const links = ledger.dagEdges.map(edge => ({
      source: nodes.find(n => n.id === edge.fromEventId),
      target: nodes.find(n => n.id === edge.toEventId),
      type: edge.type
    })).filter(l => l.source && l.target)

    // Draw links
    svg.selectAll('line')
      .data(links)
      .enter()
      .append('line')
      .attr('x1', d => d.source!.x)
      .attr('y1', d => d.source!.y)
      .attr('x2', d => d.target!.x)
      .attr('y2', d => d.target!.y)
      .attr('stroke', d => d.type === 'SYNTHESIS' ? '#3b82f6' : '#64748b')
      .attr('stroke-width', 2)
      .attr('stroke-dasharray', d => d.type === 'SYNTHESIS' ? '5,5' : 'none')

    // Draw nodes
    svg.selectAll('circle')
      .data(nodes)
      .enter()
      .append('circle')
      .attr('cx', d => d.x)
      .attr('cy', d => d.y)
      .attr('r', nodeRadius)
      .attr('fill', d => {
        if (d.type === 'MUTATION') return d.bghRelevant ? '#22c55e' : '#eab308'
        if (d.type === 'SYNTHESIS') return '#3b82f6'
        if (d.type === 'SEGMENTATION') return '#ef4444'
        return '#64748b'
      })
      .attr('stroke', '#1e293b')
      .attr('stroke-width', 2)

    // Add labels
    svg.selectAll('text')
      .data(nodes)
      .enter()
      .append('text')
      .attr('x', d => d.x)
      .attr('y', d => d.y + 5)
      .attr('text-anchor', 'middle')
      .attr('fill', 'white')
      .attr('font-size', '10px')
      .text(d => d.sequence)

  }, [ledgerId, getLedger])

  return (
    <div className="ledger-visualizer">
      <svg ref={svgRef} width="600" height="300" viewBox="0 0 600 300" />
      <div className="legend">
        <span className="legend-item"><span className="dot green"/> BGH Relevant</span>
        <span className="legend-item"><span className="dot yellow"/> Mutation</span>
        <span className="legend-item"><span className="dot blue"/> Synthesis</span>
        <span className="legend-item"><span className="dot red"/> Segmentation</span>
      </div>
    </div>
  )
}

export default LedgerVisualizer
