import React, { useState, useEffect } from 'react'
import { useCompliance } from '../../hooks/useCompliance'
import { useLedger } from '../../hooks/useLedger'
import BGHStatusWidget from './BGHStatusWidget'
import LedgerVisualizer from './LedgerVisualizer'
import EvidenceExporter from './EvidenceExporter'
import VerificationPanel from './VerificationPanel'
import { ComplianceStatus } from '../../types/forensic'

const ComplianceDashboard: React.FC = () => {
  const [status, setStatus] = useState<ComplianceStatus | null>(null)
  const [selectedLedger, setSelectedLedger] = useState<string>('')
  const { connect, disconnect, isConnected } = useCompliance()
  const { ledgers, createLedger } = useLedger()

  useEffect(() => {
    if (!selectedLedger) return

    const ws = connect(selectedLedger, (update) => {
      setStatus(update.status)
    })

    return () => disconnect(ws)
  }, [selectedLedger])

  return (
    <div className="compliance-dashboard">
      <div className="dashboard-header">
        <h1>🔒 Forensic Compliance Dashboard</h1>
        <div className="connection-status">
          {isConnected ? '🟢 Live' : '🔴 Offline'}
        </div>
      </div>

      <div className="ledger-selector">
        <select 
          value={selectedLedger} 
          onChange={(e) => setSelectedLedger(e.target.value)}
        >
          <option value="">-- Select Ledger --</option>
          {ledgers.map(l => (
            <option key={l.ledgerId} value={l.ledgerId}>
              {l.assetId} ({l.ledgerId.slice(0, 8)}...)
            </option>
          ))}
        </select>
        <button onClick={() => createLedger('new-asset', 'AUDIO')}>
          + New Ledger
        </button>
      </div>

      {status && (
        <div className="status-grid">
          <div className={`status-card ${status.chainValid ? 'valid' : 'invalid'}`}>
            <div className="status-icon">🔗</div>
            <div className="status-label">Chain Valid</div>
            <div className="status-value">{status.chainValid ? 'YES' : 'NO'}</div>
          </div>

          <div className={`status-card ${status.hsmConnected ? 'valid' : 'warning'}`}>
            <div className="status-icon">🔐</div>
            <div className="status-label">HSM</div>
            <div className="status-value">{status.hsmConnected ? 'Connected' : 'Offline'}</div>
          </div>

          <div className="status-card">
            <div className="status-icon">📋</div>
            <div className="status-label">Blocks</div>
            <div className="status-value">{status.lastBlock}</div>
          </div>

          <div className={`status-card bgh-${status.bghConformity.toLowerCase()}`}>
            <div className="status-icon">⚖️</div>
            <div className="status-label">BGH Status</div>
            <div className="status-value">{status.bghConformity}</div>
          </div>
        </div>
      )}

      <div className="dashboard-grid">
        <div className="panel">
          <h2>🎵 BGH Schöpfungshöhe</h2>
          <BGHStatusWidget ledgerId={selectedLedger} />
        </div>

        <div className="panel">
          <h2>📊 Ledger Visualization</h2>
          <LedgerVisualizer ledgerId={selectedLedger} />
        </div>

        <div className="panel">
          <h2>📄 Evidence Export</h2>
          <EvidenceExporter ledgerId={selectedLedger} />
        </div>

        <div className="panel">
          <h2>✓ Verification</h2>
          <VerificationPanel ledgerId={selectedLedger} />
        </div>
      </div>
    </div>
  )
}

export default ComplianceDashboard
