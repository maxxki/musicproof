import React, { useState } from 'react'
import { ComplianceAPI } from '../../services/compliance'

const VerificationPanel: React.FC<{ ledgerId: string }> = ({ ledgerId }) => {
  const [verifying, setVerifying] = useState(false)
  const [result, setResult] = useState<any>(null)

  const handleVerify = async () => {
    if (!ledgerId) return
    setVerifying(true)
    try {
      const response = await ComplianceAPI.verifyLedger(ledgerId)
      setResult(response)
    } catch (e) {
      setResult({ error: String(e) })
    } finally {
      setVerifying(false)
    }
  }

  return (
    <div className="verification-panel">
      <button 
        onClick={handleVerify}
        disabled={!ledgerId || verifying}
        className="verify-btn"
      >
        {verifying ? '🔍 Verifying...' : '✓ Verify Integrity'}
      </button>

      {result && (
        <div className={`verification-result ${result.valid ? 'valid' : 'invalid'}`}>
          <div className="verify-header">
            {result.valid ? '✅ VALID' : '❌ INVALID'}
          </div>
          {result.report && (
            <div className="verify-details">
              <div>Blocks: {result.report.blocks_count}</div>
              <div>Chain: {result.report.checks?.chain_continuous ? '✓' : '✗'}</div>
              <div>Merkle: {result.report.checks?.merkle_root_valid ? '✓' : '✗'}</div>
              <div>BGH: {result.report.checks?.bgh_computed ? '✓' : '✗'}</div>
            </div>
          )}
        </div>
      )}
    </div>
  )
}

export default VerificationPanel
