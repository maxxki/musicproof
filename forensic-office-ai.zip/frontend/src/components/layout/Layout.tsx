import React from 'react'
import { Link, useLocation } from 'react-router-dom'

interface LayoutProps {
  children: React.ReactNode
}

const Layout: React.FC<LayoutProps> = ({ children }) => {
  const location = useLocation()

  const navItems = [
    { path: '/', label: '🔒 Compliance', icon: 'shield' },
    { path: '/chat', label: '💬 Chat', icon: 'message' },
    { path: '/editor', label: '📝 Editor', icon: 'edit' },
  ]

  return (
    <div className="app-layout">
      <aside className="sidebar">
        <div className="logo">
          <h1>ForensicOffice</h1>
          <span className="version">AI v1.0</span>
        </div>
        <nav className="nav">
          {navItems.map(item => (
            <Link
              key={item.path}
              to={item.path}
              className={location.pathname === item.path ? 'active' : ''}
            >
              {item.label}
            </Link>
          ))}
        </nav>
        <div className="status-bar">
          <div className="status-item">
            <span className="indicator online" /> Local AI
          </div>
          <div className="status-item">
            <span className="indicator secure" /> HSM Ready
          </div>
        </div>
      </aside>
      <main className="main-content">
        {children}
      </main>
    </div>
  )
}

export default Layout
