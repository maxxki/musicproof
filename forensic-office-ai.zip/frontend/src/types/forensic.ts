// shared/types/forensic.ts
// Forensic Provenance Protocol TypeScript interfaces

export type EdgeType = 'IDENTICAL' | 'MUTATION' | 'SYNTHESIS' | 'SEGMENTATION';

export interface EdgeDefinition {
  type: EdgeType;
  arity: number;
  logic: string;
  parentHashes: string[];
  contributions?: ContributionWeight[];
}

export interface ContributionWeight {
  contributorIdHash: string;
  percentage: number;
  mutationsCount: number;
}

export interface StateVerification {
  parentHash: string;
  hashVerified: boolean;
  signatureVerified: boolean;
  timestampVerified: boolean;
  corruptionDetected: boolean;
  verificationTimeUnixNs: bigint;
  verifierIdHash: string;
}

export type SourceType = 'HUMAN' | 'AI_ASSISTANT' | 'AUTOMATION' | 'SCRIPT' | 'EXTERNAL_DEVICE';
export type ActionOrigin = 'MOUSE' | 'KEYBOARD' | 'MIDI' | 'TOUCH' | 'VOICE' | 'API' | 'PLUGIN' | 'OSC' | 'DMX' | 'PEN';

export interface ActorIdentity {
  idHash: string;
  sourceType: SourceType;
  actionOrigin: ActionOrigin;
  identityVerified: boolean;
  verificationNonce: string;
}

export interface Decision {
  confirmationRequired: boolean;
  confirmationTimestampUnixNs?: bigint;
  confirmationMethod: 'CLICK' | 'VOICE_COMMAND' | 'MIDI_CC' | 'API_CALL' | 'THRESHOLD_TRIGGER' | 'BIOMETRIC' | 'UNSPECIFIED';
  intentDescription: string;
}

export interface ActionCausality {
  initiator: ActorIdentity;
  executor: ActorIdentity;
  validator?: ActorIdentity;
  decision: Decision;
}

export interface HardwareInput {
  deviceType: 'MIDI_CONTROLLER' | 'AUDIO_INTERFACE' | 'TABLET' | 'MOUSE' | 'KEYBOARD' | 'TOUCHSCREEN' | 'MICROPHONE' | 'OSC_CONTROLLER' | 'PEN_TABLET' | 'CUSTOM_HID';
  deviceSerialHash: string;
  controlId: string;
  inputChannel?: number;
  oscAddress?: string;
  rawValueRange: {
    min: number;
    max: number;
    unit: string;
  };
  movement?: {
    durationMs: number;
    velocityCurve: 'LINEAR' | 'EXPONENTIAL' | 'LOGARITHMIC' | 'STEP' | 'BEZIER';
    startPosition: number;
    endPosition: number;
    samples?: Array<{
      timestampMs: number;
      position: number;
      velocity: number;
    }>;
  };
}

export interface FixedPointValue {
  rawValue: number;
  scaleFactor: number;
  displayString: string;
}

export interface ParameterDelta {
  pluginId: string;
  pluginVersion: string;
  pluginBinaryHash: string;
  parameterPath: string;
  parameterName: string;
  oldValue: FixedPointValue;
  newValue: FixedPointValue;
  changeType: 'ABSOLUTE' | 'RELATIVE' | 'TOGGLE' | 'ENUM' | 'CONTINUOUS';
  unit: string;
  presetBefore?: string;
  presetAfter?: string;
  automationEnvelopeActive?: boolean;
  automationPointsCount?: number;
}

export interface EnvironmentManifest {
  software: {
    name: string;
    version: string;
    binaryHash: string;
    buildTimestamp: string;
    licenseHash?: string;
  };
  plugins: Array<{
    id: string;
    name: string;
    version: string;
    vendor: string;
    binaryHash: string;
    apiVersion: string;
  }>;
  system: {
    os: string;
    osVersion: string;
    kernelHash?: string;
    hardwareFingerprintHash: string;
    cpuFeatures: string[];
    secureBootEnabled?: boolean;
    tpmPresent?: boolean;
  };
  configSnapshotJson: string;
}

export type EngagementState = 'IDLE' | 'ACTIVE' | 'BACKGROUND_RENDER' | 'EXPORT' | 'AUTOMATION_PLAYBACK' | 'AI_GENERATION';

export interface TrustAnchor {
  signature: string;
  certificateChain: string[];
  hsmKeyId?: string;
  tsaTelekom: TSAProof;
  tsaSwisssign: TSAProof;
  localTimestampUnixNs: bigint;
  blockchain?: BlockchainAnchor;
}

export interface TSAProof {
  tsaUrl: string;
  rfc3161Response: string;
  timestampedHash: string;
  claimedTimeUnixNs: bigint;
}

export interface BlockchainAnchor {
  network: 'BITCOIN' | 'ETHEREUM' | 'POLYGON';
  txid: string;
  blockHeight: number;
  merkleProof: string;
}

export interface ProofBlock {
  eventId: string;
  sequenceNumber: number;
  timestampUnixNs: bigint;
  assetId: string;
  sessionId: string;
  edge: EdgeDefinition;
  inputVerification: StateVerification;
  causality: ActionCausality;
  hardwareInput?: HardwareInput;
  parameterDelta?: ParameterDelta;
  environment: EnvironmentManifest;
  engagementState: EngagementState;
  engagementDurationMs: number;
  outputVerification: StateVerification;
  inputContentHash: string;
  outputContentHash: string;
  deltaContentHash?: string;
  trust: TrustAnchor;
  bghRelevant: boolean;
  editDurationMs: number;
  metadataNonce: string;
}

export interface ForensicLedger {
  schemaVersion: string;
  ledgerId: string;
  assetId: string;
  assetType: 'AUDIO' | 'TEXT' | 'IMAGE' | 'VIDEO' | 'DOCUMENT' | 'CODE' | 'MIXED';
  genesisBlock: ProofBlock;
  blocks: ProofBlock[];
  dagEdges: Array<{
    fromEventId: string;
    toEventId: string;
    type: EdgeType;
    weight: number;
  }>;
  merkleRoot: string;
  state: 'ACTIVE' | 'FINALIZED' | 'ARCHIVED' | 'DISPUTED';
  bghCompliance: {
    humanInitiatedMutations: number;
    humanExecutedMutations: number;
    aiSuggestedMutations: number;
    automationExecutedMutations: number;
    totalEditDurationMs: number;
    thresholdPassed: boolean;
    schöpfungshöheEstimate: 'UNLIKELY' | 'POSSIBLE' | 'LIKELY' | 'CERTAIN';
    contributions: ContributionWeight[];
  };
}

export interface ComplianceStatus {
  ledgerId: string;
  chainValid: boolean;
  lastBlock: number;
  hsmConnected: boolean;
  tsaStatus: string;
  bghConformity: string;
  humanMutations: number;
  totalDurationSec: number;
}
