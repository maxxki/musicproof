import React from 'react'
import { BrowserRouter, Routes, Route } from 'react-router-dom'
import Layout from './components/layout/Layout'
import ComplianceDashboard from './components/compliance/ComplianceDashboard'
import ChatPanel from './components/chat/ChatPanel'
import Editor from './components/editor/RichTextEditor'

const App: React.FC = () => {
  return (
    <BrowserRouter>
      <Layout>
        <Routes>
          <Route path="/" element={<ComplianceDashboard />} />
          <Route path="/chat" element={<ChatPanel />} />
          <Route path="/editor" element={<Editor />} />
        </Routes>
      </Layout>
    </BrowserRouter>
  )
}

export default App
