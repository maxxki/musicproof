import { useState, useCallback } from 'react'
import { LedgerAPI } from '../services/ledger'
import { ForensicLedger } from '../types/forensic'

export function useLedger() {
  const [ledgers, setLedgers] = useState<ForensicLedger[]>([])
  const [loading, setLoading] = useState(false)

  const loadLedgers = useCallback(async () => {
    setLoading(true)
    try {
      const data = await LedgerAPI.list()
      setLedgers(data)
    } finally {
      setLoading(false)
    }
  }, [])

  const createLedger = useCallback(async (assetId: string, assetType: string) => {
    const ledger = await LedgerAPI.create(assetId, assetType)
    setLedgers(prev => [...prev, ledger])
    return ledger
  }, [])

  return { ledgers, loading, loadLedgers, createLedger }
}
