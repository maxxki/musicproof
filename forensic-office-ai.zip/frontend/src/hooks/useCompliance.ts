import { useState, useCallback, useRef } from 'react'
import { ComplianceStatus } from '../types/forensic'

export function useCompliance() {
  const [isConnected, setIsConnected] = useState(false)
  const wsRef = useRef<WebSocket | null>(null)

  const connect = useCallback((ledgerId: string, onUpdate: (update: any) => void) => {
    const ws = new WebSocket(`ws://localhost:8000/api/compliance/stream/${ledgerId}`)

    ws.onopen = () => setIsConnected(true)
    ws.onmessage = (event) => {
      const update = JSON.parse(event.data)
      onUpdate(update)
    }
    ws.onclose = () => setIsConnected(false)
    ws.onerror = () => setIsConnected(false)

    wsRef.current = ws
    return ws
  }, [])

  const disconnect = useCallback((ws?: WebSocket) => {
    const socket = ws || wsRef.current
    if (socket) {
      socket.close()
      setIsConnected(false)
    }
  }, [])

  return { connect, disconnect, isConnected }
}
