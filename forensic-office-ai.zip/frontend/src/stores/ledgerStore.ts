import { create } from 'zustand'
import { ForensicLedger } from '../types/forensic'

interface LedgerStore {
  ledgers: Map<string, ForensicLedger>
  addLedger: (ledger: ForensicLedger) => void
  getLedger: (id: string) => ForensicLedger | undefined
  updateLedger: (id: string, updates: Partial<ForensicLedger>) => void
}

export const useLedgerStore = create<LedgerStore>((set, get) => ({
  ledgers: new Map(),

  addLedger: (ledger) => set(state => {
    const newMap = new Map(state.ledgers)
    newMap.set(ledger.ledgerId, ledger)
    return { ledgers: newMap }
  }),

  getLedger: (id) => get().ledgers.get(id),

  updateLedger: (id, updates) => set(state => {
    const existing = state.ledgers.get(id)
    if (!existing) return state
    const newMap = new Map(state.ledgers)
    newMap.set(id, { ...existing, ...updates })
    return { ledgers: newMap }
  })
}))
